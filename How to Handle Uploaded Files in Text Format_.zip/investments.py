from flask import Blueprint, jsonify, request
from src.models.financial import db, Investment, Transaction
from src.models.project import Project
from src.main import token_required
import datetime

investments_bp = Blueprint('investments', __name__)

@investments_bp.route('/', methods=['GET'])
@token_required
def get_user_investments(current_user):
    # Get pagination parameters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # Get user investments with pagination
    investments_pagination = Investment.query.filter_by(user_id=current_user.id).order_by(
        Investment.investment_date.desc()
    ).paginate(page=page, per_page=per_page)
    
    # Format response
    investments = []
    for investment in investments_pagination.items:
        project = Project.query.get(investment.project_id) if investment.project_id else None
        
        investments.append({
            'id': investment.id,
            'project_id': investment.project_id,
            'project_title': project.title if project else None,
            'amount': float(investment.amount),
            'investment_date': investment.investment_date.strftime('%Y-%m-%d %H:%M:%S'),
            'expected_return_rate': float(investment.expected_return_rate) if investment.expected_return_rate else None,
            'status': investment.status,
            'return_amount': float(investment.return_amount) if investment.return_amount else None,
            'return_date': investment.return_date.strftime('%Y-%m-%d') if investment.return_date else None,
            'created_at': investment.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify({
        'investments': investments,
        'total': investments_pagination.total,
        'pages': investments_pagination.pages,
        'current_page': investments_pagination.page
    }), 200

@investments_bp.route('/<int:investment_id>', methods=['GET'])
@token_required
def get_investment(current_user, investment_id):
    investment = Investment.query.get_or_404(investment_id)
    
    # Check if the investment belongs to the current user
    if investment.user_id != current_user.id:
        # Check if user has admin role
        has_admin_role = False
        for role in current_user.roles:
            if role.name == 'admin' or role.name == 'financial_manager':
                has_admin_role = True
                break
        
        if not has_admin_role:
            return jsonify({'message': 'Unauthorized access!'}), 403
    
    project = Project.query.get(investment.project_id) if investment.project_id else None
    transaction = Transaction.query.get(investment.transaction_id) if investment.transaction_id else None
    
    return jsonify({
        'id': investment.id,
        'project_id': investment.project_id,
        'project_title': project.title if project else None,
        'transaction_id': investment.transaction_id,
        'transaction_reference': transaction.transaction_reference if transaction else None,
        'amount': float(investment.amount),
        'investment_date': investment.investment_date.strftime('%Y-%m-%d %H:%M:%S'),
        'expected_return_rate': float(investment.expected_return_rate) if investment.expected_return_rate else None,
        'status': investment.status,
        'return_amount': float(investment.return_amount) if investment.return_amount else None,
        'return_date': investment.return_date.strftime('%Y-%m-%d') if investment.return_date else None,
        'created_at': investment.created_at.strftime('%Y-%m-%d %H:%M:%S'),
        'updated_at': investment.updated_at.strftime('%Y-%m-%d %H:%M:%S')
    }), 200

@investments_bp.route('/', methods=['POST'])
@token_required
def create_investment(current_user):
    data = request.get_json()
    
    # Check required fields
    required_fields = ['project_id', 'amount']
    for field in required_fields:
        if field not in data:
            return jsonify({'message': f'Field {field} is required!'}), 400
    
    # Check if project exists and is active
    project = Project.query.get_or_404(data['project_id'])
    if project.status != 'active':
        return jsonify({'message': 'Project is not active for investments!'}), 400
    
    # Check if amount meets minimum investment requirement
    if project.min_investment and float(data['amount']) < float(project.min_investment):
        return jsonify({'message': f'Minimum investment amount is {project.min_investment}!'}), 400
    
    # Create transaction record
    transaction = Transaction(
        user_id=current_user.id,
        project_id=project.id,
        transaction_type='investment',
        amount=data['amount'],
        status='pending',
        payment_method=data.get('payment_method'),
        description=f'Investment in project: {project.title}',
    )
    
    db.session.add(transaction)
    db.session.flush()  # Get transaction ID without committing
    
    # Create investment record
    investment = Investment(
        user_id=current_user.id,
        project_id=project.id,
        transaction_id=transaction.id,
        amount=data['amount'],
        expected_return_rate=project.expected_return,
        status='pending'
    )
    
    db.session.add(investment)
    
    # Update project's current amount (will be confirmed later)
    # project.current_amount = project.current_amount + data['amount']
    
    db.session.commit()
    
    return jsonify({
        'message': 'Investment request submitted successfully!',
        'investment_id': investment.id,
        'transaction_id': transaction.id
    }), 201

@investments_bp.route('/<int:investment_id>/confirm', methods=['POST'])
@token_required
def confirm_investment(current_user, investment_id):
    # Check if user has financial_manager or admin role
    has_permission = False
    for role in current_user.roles:
        if role.name in ['admin', 'financial_manager']:
            has_permission = True
            break
    
    if not has_permission:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    investment = Investment.query.get_or_404(investment_id)
    
    if investment.status != 'pending':
        return jsonify({'message': 'Investment is not in pending status!'}), 400
    
    # Update investment status
    investment.status = 'active'
    
    # Update related transaction
    if investment.transaction_id:
        transaction = Transaction.query.get(investment.transaction_id)
        if transaction:
            transaction.status = 'completed'
    
    # Update project's current amount
    if investment.project_id:
        project = Project.query.get(investment.project_id)
        if project:
            project.current_amount = project.current_amount + investment.amount
    
    db.session.commit()
    
    return jsonify({'message': 'Investment confirmed successfully!'}), 200

@investments_bp.route('/<int:investment_id>/cancel', methods=['POST'])
@token_required
def cancel_investment(current_user, investment_id):
    investment = Investment.query.get_or_404(investment_id)
    
    # Check if the investment belongs to the current user or user has admin role
    if investment.user_id != current_user.id:
        has_admin_role = False
        for role in current_user.roles:
            if role.name in ['admin', 'financial_manager']:
                has_admin_role = True
                break
        
        if not has_admin_role:
            return jsonify({'message': 'Unauthorized access!'}), 403
    
    if investment.status != 'pending':
        return jsonify({'message': 'Only pending investments can be cancelled!'}), 400
    
    # Update investment status
    investment.status = 'cancelled'
    
    # Update related transaction
    if investment.transaction_id:
        transaction = Transaction.query.get(investment.transaction_id)
        if transaction:
            transaction.status = 'cancelled'
    
    db.session.commit()
    
    return jsonify({'message': 'Investment cancelled successfully!'}), 200

@investments_bp.route('/transactions', methods=['GET'])
@token_required
def get_user_transactions(current_user):
    # Get pagination parameters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # Get user transactions with pagination
    transactions_pagination = Transaction.query.filter_by(user_id=current_user.id).order_by(
        Transaction.created_at.desc()
    ).paginate(page=page, per_page=per_page)
    
    # Format response
    transactions = []
    for transaction in transactions_pagination.items:
        project = Project.query.get(transaction.project_id) if transaction.project_id else None
        
        transactions.append({
            'id': transaction.id,
            'transaction_type': transaction.transaction_type,
            'amount': float(transaction.amount),
            'currency': transaction.currency,
            'status': transaction.status,
            'payment_method': transaction.payment_method,
            'transaction_reference': transaction.transaction_reference,
            'description': transaction.description,
            'project_id': transaction.project_id,
            'project_title': project.title if project else None,
            'created_at': transaction.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify({
        'transactions': transactions,
        'total': transactions_pagination.total,
        'pages': transactions_pagination.pages,
        'current_page': transactions_pagination.page
    }), 200

@investments_bp.route('/transactions/<int:transaction_id>', methods=['GET'])
@token_required
def get_transaction(current_user, transaction_id):
    transaction = Transaction.query.get_or_404(transaction_id)
    
    # Check if the transaction belongs to the current user
    if transaction.user_id != current_user.id:
        # Check if user has admin role
        has_admin_role = False
        for role in current_user.roles:
            if role.name == 'admin' or role.name == 'financial_manager':
                has_admin_role = True
                break
        
        if not has_admin_role:
            return jsonify({'message': 'Unauthorized access!'}), 403
    
    project = Project.query.get(transaction.project_id) if transaction.project_id else None
    
    return jsonify({
        'id': transaction.id,
        'transaction_type': transaction.transaction_type,
        'amount': float(transaction.amount),
        'currency': transaction.currency,
        'status': transaction.status,
        'payment_method': transaction.payment_method,
        'transaction_reference': transaction.transaction_reference,
        'description': transaction.description,
        'project_id': transaction.project_id,
        'project_title': project.title if project else None,
        'created_at': transaction.created_at.strftime('%Y-%m-%d %H:%M:%S'),
        'updated_at': transaction.updated_at.strftime('%Y-%m-%d %H:%M:%S')
    }), 200
