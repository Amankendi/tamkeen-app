import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import MainLayout from '../layouts/MainLayout';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/ui/use-toast';

const InvestmentGroupDetailsPage: React.FC = () => {
  const { groupId } = useParams<{ groupId: string }>();
  const [group, setGroup] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [investmentAmount, setInvestmentAmount] = useState('');
  const [joinLoading, setJoinLoading] = useState(false);
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchGroupDetails = async () => {
      try {
        // محاكاة طلب API لتفاصيل المجموعة
        setTimeout(() => {
          const mockGroup = {
            id: parseInt(groupId || '1'),
            name: "مجموعة الاستثمار الزراعي",
            description: "مجموعة متخصصة في الاستثمار في المشاريع الزراعية المستدامة في المناطق الريفية. نهدف إلى دعم المزارعين المحليين وتحسين جودة الإنتاج الزراعي، مع تحقيق عوائد مجزية للمستثمرين. تركز المجموعة على المشاريع الزراعية العضوية والمستدامة التي تحافظ على البيئة وتدعم المجتمعات المحلية.",
            image: "/assets/images/group1.jpg",
            min_investment: 1000,
            target_amount: 100000,
            current_amount: 65000,
            status: "active",
            created_at: "2025-01-10T08:30:00Z",
            project: {
              id: 1,
              name: "مشروع زراعة الكاكاو العضوي"
            },
            creator: {
              id: 2,
              username: "أحمد محمد"
            },
            members: [
              {
                id: 2,
                username: "أحمد محمد",
                role: "leader",
                investment_amount: 10000,
                joined_at: "2025-01-10T08:30:00Z"
              },
              {
                id: 3,
                username: "سارة علي",
                role: "member",
                investment_amount: 5000,
                joined_at: "2025-01-12T10:15:00Z"
              },
              {
                id: 4,
                username: "محمد خالد",
                role: "member",
                investment_amount: 8000,
                joined_at: "2025-01-15T14:20:00Z"
              },
              {
                id: 5,
                username: "نورا أحمد",
                role: "member",
                investment_amount: 3000,
                joined_at: "2025-01-18T09:45:00Z"
              }
            ],
            investments: [
              {
                id: 1,
                project_id: 1,
                project_name: "مشروع زراعة الكاكاو العضوي",
                amount: 30000,
                status: "approved",
                created_at: "2025-01-20T11:30:00Z"
              },
              {
                id: 2,
                project_id: 5,
                project_name: "مشروع تطوير نظام ري ذكي",
                amount: 15000,
                status: "pending",
                created_at: "2025-02-05T13:45:00Z"
              }
            ],
            active_votes: [
              {
                id: 1,
                title: "استثمار في مشروع تربية النحل العضوي",
                description: "التصويت على استثمار مبلغ 20,000 دولار في مشروع تربية النحل العضوي في المناطق الجبلية",
                vote_type: "project_investment",
                status: "active",
                start_date: "2025-02-10T09:00:00Z",
                end_date: "2025-02-17T09:00:00Z",
                votes_count: 3,
                votes_results: {
                  yes: 2,
                  no: 1,
                  abstain: 0
                }
              }
            ],
            user_membership: user?.id ? {
              role: user.id === 2 ? "leader" : null,
              investment_amount: user.id === 2 ? 10000 : 0,
              has_voted: false
            } : null
          };
          
          setGroup(mockGroup);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Error fetching group details:', error);
        setLoading(false);
      }
    };

    fetchGroupDetails();
  }, [groupId, user]);

  const handleJoinGroup = () => {
    if (!isAuthenticated) {
      toast({
        title: "يرجى تسجيل الدخول",
        description: "يجب عليك تسجيل الدخول للانضمام إلى المجموعة الاستثمارية",
        variant: "destructive",
      });
      navigate('/login');
      return;
    }

    const amount = parseFloat(investmentAmount);
    if (isNaN(amount) || amount < (group?.min_investment || 0)) {
      toast({
        title: "مبلغ غير صالح",
        description: `الحد الأدنى للاستثمار هو ${group?.min_investment} دولار`,
        variant: "destructive",
      });
      return;
    }

    setJoinLoading(true);

    // محاكاة طلب API للانضمام إلى المجموعة
    setTimeout(() => {
      toast({
        title: "تم الانضمام بنجاح",
        description: `تم انضمامك إلى مجموعة ${group?.name} بمبلغ ${amount} دولار`,
      });
      
      // تحديث حالة المجموعة
      setGroup(prev => ({
        ...prev,
        current_amount: prev.current_amount + amount,
        members: [...prev.members, {
          id: user?.id,
          username: user?.username,
          role: "member",
          investment_amount: amount,
          joined_at: new Date().toISOString()
        }],
        user_membership: {
          role: "member",
          investment_amount: amount,
          has_voted: false
        }
      }));
      
      setJoinLoading(false);
      setInvestmentAmount('');
    }, 1500);
  };

  const handleVote = (voteId: number, response: string) => {
    if (!isAuthenticated) {
      toast({
        title: "يرجى تسجيل الدخول",
        description: "يجب عليك تسجيل الدخول للتصويت",
        variant: "destructive",
      });
      navigate('/login');
      return;
    }

    // محاكاة طلب API للتصويت
    setTimeout(() => {
      toast({
        title: "تم التصويت بنجاح",
        description: "تم تسجيل تصويتك بنجاح",
      });
      
      // تحديث حالة التصويت
      setGroup(prev => {
        const updatedVotes = prev.active_votes.map((vote: any) => {
          if (vote.id === voteId) {
            const updatedResults = { ...vote.votes_results };
            updatedResults[response] += 1;
            
            return {
              ...vote,
              votes_count: vote.votes_count + 1,
              votes_results: updatedResults
            };
          }
          return vote;
        });
        
        return {
          ...prev,
          active_votes: updatedVotes,
          user_membership: {
            ...prev.user_membership,
            has_voted: true
          }
        };
      });
    }, 1000);
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-12">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!group) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">المجموعة غير موجودة</h2>
            <p className="mb-6">لم يتم العثور على المجموعة الاستثمارية المطلوبة.</p>
            <Link to="/investment-groups" className="btn btn-primary">
              العودة إلى المجموعات
            </Link>
          </div>
        </div>
      </MainLayout>
    );
  }

  const isGroupMember = group.user_membership?.role !== null;
  const isGroupLeader = group.user_membership?.role === 'leader';
  const fundingPercentage = Math.round((group.current_amount / group.target_amount) * 100);

  return (
    <MainLayout>
      <div className="bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          {/* رأس الصفحة */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
            <div className="relative">
              <img 
                src={group.image} 
                alt={group.name} 
                className="w-full h-64 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                <div className="p-6 text-white">
                  <h1 className="text-3xl font-bold mb-2">{group.name}</h1>
                  <div className="flex items-center space-x-4 space-x-reverse">
                    <span className="bg-primary/20 text-white text-sm font-medium px-2.5 py-0.5 rounded">
                      {group.members.length} عضو
                    </span>
                    <span className="text-white/80 text-sm">
                      تم الإنشاء في {new Date(group.created_at).toLocaleDateString('ar-EG')}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* شريط التقدم */}
            <div className="p-6 border-b border-gray-200">
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">التمويل المستهدف: ${group.target_amount.toLocaleString()}</span>
                <span className="text-primary font-medium">{fundingPercentage}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
                <div className="bg-primary h-2.5 rounded-full" style={{ width: `${fundingPercentage}%` }}></div>
              </div>
              <div className="flex justify-between text-sm text-gray-600">
                <span>المبلغ الحالي: ${group.current_amount.toLocaleString()}</span>
                <span>الحد الأدنى للاستثمار: ${group.min_investment.toLocaleString()}</span>
              </div>
            </div>
            
            {/* أزرار الإجراءات */}
            <div className="p-6 bg-gray-50 flex flex-wrap gap-4 justify-between items-center">
              <div className="flex flex-wrap gap-2">
                <button 
                  className={`btn ${activeTab === 'overview' ? 'btn-primary' : 'btn-outline'}`}
                  onClick={() => setActiveTab('overview')}
                >
                  نظرة عامة
                </button>
                <button 
                  className={`btn ${activeTab === 'members' ? 'btn-primary' : 'btn-outline'}`}
                  onClick={() => setActiveTab('members')}
                >
                  الأعضاء
                </button>
                <button 
                  className={`btn ${activeTab === 'investments' ? 'btn-primary' : 'btn-outline'}`}
                  onClick={() => setActiveTab('investments')}
                >
                  الاستثمارات
                </button>
                <button 
                  className={`btn ${activeTab === 'votes' ? 'btn-primary' : 'btn-outline'}`}
                  onClick={() => setActiveTab('votes')}
                >
                  التصويتات
                </button>
              </div>
              
              {!isGroupMember && (
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    placeholder={`الحد الأدنى ${group.min_investment}$`}
                    className="input input-bordered w-40"
                    value={investmentAmount}
                    onChange={(e) => setInvestmentAmount(e.target.value)}
                    min={group.min_investment}
                  />
                  <button 
                    className="btn btn-primary"
                    onClick={handleJoinGroup}
                    disabled={joinLoading}
                  >
                    {joinLoading ? (
                      <>
                        <span className="loading loading-spinner loading-sm"></span>
                        جاري الانضمام...
                      </>
                    ) : 'انضمام للمجموعة'}
                  </button>
                </div>
              )}
              
              {isGroupMember && (
                <div>
                  <span className="text-gray-700 ml-2">استثمارك: ${group.user_membership.investment_amount.toLocaleString()}</span>
                  {isGroupLeader && (
                    <Link to={`/investment-groups/${group.id}/manage`} className="btn btn-primary ml-2">
                      إدارة المجموعة
                    </Link>
                  )}
                </div>
              )}
            </div>
          </div>
          
          {/* محتوى التبويب النشط */}
          <div className="bg-white rounded-lg shadow-md p-6">
            {activeTab === 'overview' && (
              <div>
                <h2 className="text-2xl font-bold mb-4">نبذة عن المجموعة</h2>
                <p className="text-gray-700 mb-6 whitespace-pre-line">
                  {group.description}
                </p>
                
                {group.project && (
                  <div className="mt-8">
                    <h3 className="text-xl font-bold mb-4">المشروع الرئيسي</h3>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <Link to={`/projects/${group.project.id}`} className="text-primary font-medium hover:underline">
                        {group.project.name}
                      </Link>
                      <p className="text-gray-700 mt-2">
                        هذه المجموعة تركز بشكل أساسي على الاستثمار في هذا المشروع، ولكن يمكنها أيضاً الاستثمار في مشاريع أخرى ذات صلة.
                      </p>
                    </div>
                  </div>
                )}
                
                <div className="mt-8">
                  <h3 className="text-xl font-bold mb-4">إحصائيات المجموعة</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gray-50 p-4 rounded-lg text-center">
                      <p className="text-gray-600 mb-1">عدد الأعضاء</p>
                      <p className="text-2xl font-bold text-primary">{group.members.length}</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg text-center">
                      <p className="text-gray-600 mb-1">إجمالي الاستثمارات</p>
                      <p className="text-2xl font-bold text-primary">
                        ${group.investments.reduce((sum: number, inv: any) => sum + inv.amount, 0).toLocaleString()}
                      </p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg text-center">
                      <p className="text-gray-600 mb-1">المبلغ المتاح</p>
                      <p className="text-2xl font-bold text-primary">
                        ${(group.current_amount - group.investments.reduce((sum: number, inv: any) => sum + inv.amount, 0)).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'members' && (
              <div>
                <h2 className="text-2xl font-bold mb-4">أعضاء المجموعة</h2>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-right text-gray-500">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3">العضو</th>
                        <th scope="col" className="px-6 py-3">الدور</th>
                        <th scope="col" className="px-6 py-3">مبلغ الاستثمار</th>
                        <th scope="col" className="px-6 py-3">تاريخ الانضمام</th>
                      </tr>
                    </thead>
          
(Content truncated due to size limit. Use line ranges to read in chunks)