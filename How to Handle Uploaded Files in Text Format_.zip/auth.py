from flask import Blueprint, jsonify, request
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
import datetime
from src.models.user import db, User, Role, UserProfile
from src.main import app, token_required

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    
    # Check if required fields are present
    required_fields = ['username', 'email', 'password', 'first_name', 'last_name']
    for field in required_fields:
        if field not in data:
            return jsonify({'message': f'Field {field} is required!'}), 400
    
    # Check if user already exists
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'message': 'Username already exists!'}), 409
    
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'message': 'Email already exists!'}), 409
    
    # Create new user
    hashed_password = generate_password_hash(data['password'], method='sha256')
    new_user = User(
        username=data['username'],
        email=data['email'],
        password_hash=hashed_password
    )
    
    # Add user role (default: 'user')
    user_role = Role.query.filter_by(name='user').first()
    if user_role:
        new_user.roles.append(user_role)
    
    db.session.add(new_user)
    db.session.commit()
    
    # Create user profile
    new_profile = UserProfile(
        user_id=new_user.id,
        first_name=data['first_name'],
        last_name=data['last_name'],
        phone_number=data.get('phone_number'),
        gender=data.get('gender'),
        nationality=data.get('nationality'),
        address=data.get('address'),
        city=data.get('city'),
        country=data.get('country')
    )
    
    db.session.add(new_profile)
    db.session.commit()
    
    return jsonify({'message': 'User registered successfully!'}), 201

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'message': 'Username and password are required!'}), 400
    
    user = User.query.filter_by(username=data['username']).first()
    
    if not user:
        return jsonify({'message': 'Invalid username or password!'}), 401
    
    if check_password_hash(user.password_hash, data['password']):
        # Generate JWT token
        token = jwt.encode({
            'user_id': user.id,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(days=1)
        }, app.config['SECRET_KEY'], algorithm="HS256")
        
        # Update last login
        user.last_login = datetime.datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Login successful!',
            'token': token,
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'roles': [role.name for role in user.roles]
            }
        }), 200
    
    return jsonify({'message': 'Invalid username or password!'}), 401

@auth_bp.route('/verify-token', methods=['GET'])
@token_required
def verify_token(current_user):
    return jsonify({
        'message': 'Token is valid!',
        'user': {
            'id': current_user.id,
            'username': current_user.username,
            'email': current_user.email,
            'roles': [role.name for role in current_user.roles]
        }
    }), 200

@auth_bp.route('/reset-password-request', methods=['POST'])
def reset_password_request():
    data = request.get_json()
    
    if not data or not data.get('email'):
        return jsonify({'message': 'Email is required!'}), 400
    
    user = User.query.filter_by(email=data['email']).first()
    
    if not user:
        # Don't reveal that the user doesn't exist
        return jsonify({'message': 'If your email is registered, you will receive a password reset link.'}), 200
    
    # Generate reset token
    import uuid
    reset_token = str(uuid.uuid4())
    user.reset_token = reset_token
    db.session.commit()
    
    # In a real application, send an email with the reset link
    # For now, just return the token (for development purposes)
    return jsonify({
        'message': 'If your email is registered, you will receive a password reset link.',
        'dev_token': reset_token  # Remove this in production
    }), 200

@auth_bp.route('/reset-password', methods=['POST'])
def reset_password():
    data = request.get_json()
    
    if not data or not data.get('token') or not data.get('password'):
        return jsonify({'message': 'Token and new password are required!'}), 400
    
    user = User.query.filter_by(reset_token=data['token']).first()
    
    if not user:
        return jsonify({'message': 'Invalid or expired token!'}), 401
    
    # Update password
    user.password_hash = generate_password_hash(data['password'], method='sha256')
    user.reset_token = None
    db.session.commit()
    
    return jsonify({'message': 'Password reset successful!'}), 200

@auth_bp.route('/logout', methods=['POST'])
@token_required
def logout(current_user):
    # In a stateless JWT system, the client simply discards the token
    # Here we could implement token blacklisting if needed
    return jsonify({'message': 'Logout successful!'}), 200
