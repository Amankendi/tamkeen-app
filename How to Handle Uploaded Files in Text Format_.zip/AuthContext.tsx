import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { useToast } from '../components/ui/use-toast';

interface AuthContextType {
  user: any | null;
  token: string | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  loading: boolean;
  login: (token: string, userData: any) => void;
  logout: () => void;
  updateUser: (userData: any) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<any | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // Check if user is logged in on initial load
    const storedToken = localStorage.getItem('tamken_token');
    const storedUser = localStorage.getItem('tamken_user');
    
    if (storedToken && storedUser) {
      try {
        setToken(storedToken);
        setUser(JSON.parse(storedUser));
      } catch (error) {
        console.error('Error parsing stored user data:', error);
        localStorage.removeItem('tamken_token');
        localStorage.removeItem('tamken_user');
      }
    }
    
    setLoading(false);
  }, []);

  const login = (newToken: string, userData: any) => {
    setToken(newToken);
    setUser(userData);
    localStorage.setItem('tamken_token', newToken);
    localStorage.setItem('tamken_user', JSON.stringify(userData));
    
    toast({
      title: "تم تسجيل الدخول بنجاح",
      description: `مرحباً بك في منصة تمكين، ${userData.username}!`,
    });
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('tamken_token');
    localStorage.removeItem('tamken_user');
    
    toast({
      title: "تم تسجيل الخروج",
      description: "تم تسجيل خروجك من منصة تمكين بنجاح.",
    });
  };

  const updateUser = (userData: any) => {
    setUser(prevUser => ({
      ...prevUser,
      ...userData
    }));
    localStorage.setItem('tamken_user', JSON.stringify({
      ...user,
      ...userData
    }));
  };

  const isAuthenticated = !!token;
  const isAdmin = isAuthenticated && user?.roles?.includes('admin');

  return (
    <AuthContext.Provider value={{
      user,
      token,
      isAuthenticated,
      isAdmin,
      loading,
      login,
      logout,
      updateUser
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
