from flask import Blueprint, jsonify, request, current_app
from src.models.investment_group import InvestmentGroup, GroupMembership, GroupInvestment, GroupVote, VoteResponse, db
from src.models.user import User
from src.models.project import Project
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime, timedelta

investment_groups_bp = Blueprint('investment_groups', __name__)

# الحصول على جميع المجموعات الاستثمارية
@investment_groups_bp.route('', methods=['GET'])
def get_all_groups():
    try:
        groups = InvestmentGroup.query.all()
        result = []
        
        for group in groups:
            members_count = GroupMembership.query.filter_by(group_id=group.id).count()
            
            group_data = {
                'id': group.id,
                'name': group.name,
                'description': group.description,
                'image': group.image,
                'min_investment': group.min_investment,
                'target_amount': group.target_amount,
                'current_amount': group.current_amount,
                'status': group.status,
                'members_count': members_count,
                'created_at': group.created_at.isoformat(),
                'project': group.project.name if group.project else None
            }
            result.append(group_data)
        
        return jsonify({
            'status': 'success',
            'data': result
        }), 200
    except Exception as e:
        current_app.logger.error(f"Error getting investment groups: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': 'حدث خطأ أثناء جلب المجموعات الاستثمارية'
        }), 500

# الحصول على مجموعة استثمارية محددة
@investment_groups_bp.route('/<int:group_id>', methods=['GET'])
def get_group(group_id):
    try:
        group = InvestmentGroup.query.get(group_id)
        
        if not group:
            return jsonify({
                'status': 'error',
                'message': 'المجموعة الاستثمارية غير موجودة'
            }), 404
        
        # الحصول على معلومات الأعضاء
        memberships = GroupMembership.query.filter_by(group_id=group_id).all()
        members = []
        
        for membership in memberships:
            user = User.query.get(membership.user_id)
            members.append({
                'id': user.id,
                'username': user.username,
                'role': membership.role,
                'investment_amount': membership.investment_amount,
                'joined_at': membership.joined_at.isoformat()
            })
        
        # الحصول على معلومات الاستثمارات
        investments = GroupInvestment.query.filter_by(group_id=group_id).all()
        investments_data = []
        
        for investment in investments:
            project = Project.query.get(investment.project_id)
            investments_data.append({
                'id': investment.id,
                'project_id': project.id,
                'project_name': project.name,
                'amount': investment.amount,
                'status': investment.status,
                'created_at': investment.created_at.isoformat()
            })
        
        # الحصول على معلومات التصويتات النشطة
        active_votes = GroupVote.query.filter_by(group_id=group_id, status='active').all()
        votes_data = []
        
        for vote in active_votes:
            votes_count = VoteResponse.query.filter_by(vote_id=vote.id).count()
            votes_data.append({
                'id': vote.id,
                'title': vote.title,
                'description': vote.description,
                'vote_type': vote.vote_type,
                'status': vote.status,
                'start_date': vote.start_date.isoformat(),
                'end_date': vote.end_date.isoformat(),
                'votes_count': votes_count
            })
        
        group_data = {
            'id': group.id,
            'name': group.name,
            'description': group.description,
            'image': group.image,
            'min_investment': group.min_investment,
            'target_amount': group.target_amount,
            'current_amount': group.current_amount,
            'status': group.status,
            'created_at': group.created_at.isoformat(),
            'project': {
                'id': group.project.id,
                'name': group.project.name
            } if group.project else None,
            'creator': {
                'id': group.creator.id,
                'username': group.creator.username
            },
            'members': members,
            'investments': investments_data,
            'active_votes': votes_data
        }
        
        return jsonify({
            'status': 'success',
            'data': group_data
        }), 200
    except Exception as e:
        current_app.logger.error(f"Error getting investment group: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': 'حدث خطأ أثناء جلب المجموعة الاستثمارية'
        }), 500

# إنشاء مجموعة استثمارية جديدة
@investment_groups_bp.route('', methods=['POST'])
@jwt_required()
def create_group():
    try:
        user_id = get_jwt_identity()
        data = request.get_json()
        
        # التحقق من البيانات المطلوبة
        required_fields = ['name', 'description', 'min_investment', 'target_amount']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'status': 'error',
                    'message': f'حقل {field} مطلوب'
                }), 400
        
        # إنشاء المجموعة الاستثمارية
        new_group = InvestmentGroup(
            name=data['name'],
            description=data['description'],
            image=data.get('image'),
            min_investment=data['min_investment'],
            target_amount=data['target_amount'],
            creator_id=user_id,
            project_id=data.get('project_id')
        )
        
        db.session.add(new_group)
        db.session.flush()
        
        # إضافة المنشئ كعضو وقائد للمجموعة
        membership = GroupMembership(
            user_id=user_id,
            group_id=new_group.id,
            role='leader'
        )
        
        db.session.add(membership)
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'تم إنشاء المجموعة الاستثمارية بنجاح',
            'data': {
                'id': new_group.id,
                'name': new_group.name
            }
        }), 201
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error creating investment group: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': 'حدث خطأ أثناء إنشاء المجموعة الاستثمارية'
        }), 500

# تحديث مجموعة استثمارية
@investment_groups_bp.route('/<int:group_id>', methods=['PUT'])
@jwt_required()
def update_group(group_id):
    try:
        user_id = get_jwt_identity()
        data = request.get_json()
        
        group = InvestmentGroup.query.get(group_id)
        
        if not group:
            return jsonify({
                'status': 'error',
                'message': 'المجموعة الاستثمارية غير موجودة'
            }), 404
        
        # التحقق من أن المستخدم هو قائد المجموعة
        membership = GroupMembership.query.filter_by(user_id=user_id, group_id=group_id).first()
        
        if not membership or membership.role != 'leader':
            return jsonify({
                'status': 'error',
                'message': 'غير مصرح لك بتحديث هذه المجموعة'
            }), 403
        
        # تحديث بيانات المجموعة
        if 'name' in data:
            group.name = data['name']
        
        if 'description' in data:
            group.description = data['description']
        
        if 'image' in data:
            group.image = data['image']
        
        if 'min_investment' in data:
            group.min_investment = data['min_investment']
        
        if 'target_amount' in data:
            group.target_amount = data['target_amount']
        
        if 'status' in data:
            group.status = data['status']
        
        if 'project_id' in data:
            group.project_id = data['project_id']
        
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'تم تحديث المجموعة الاستثمارية بنجاح'
        }), 200
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error updating investment group: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': 'حدث خطأ أثناء تحديث المجموعة الاستثمارية'
        }), 500

# الانضمام إلى مجموعة استثمارية
@investment_groups_bp.route('/<int:group_id>/join', methods=['POST'])
@jwt_required()
def join_group(group_id):
    try:
        user_id = get_jwt_identity()
        data = request.get_json()
        
        group = InvestmentGroup.query.get(group_id)
        
        if not group:
            return jsonify({
                'status': 'error',
                'message': 'المجموعة الاستثمارية غير موجودة'
            }), 404
        
        # التحقق من أن المستخدم ليس عضواً بالفعل
        existing_membership = GroupMembership.query.filter_by(user_id=user_id, group_id=group_id).first()
        
        if existing_membership:
            return jsonify({
                'status': 'error',
                'message': 'أنت عضو بالفعل في هذه المجموعة'
            }), 400
        
        # التحقق من مبلغ الاستثمار
        investment_amount = data.get('investment_amount', 0)
        
        if investment_amount < group.min_investment:
            return jsonify({
                'status': 'error',
                'message': f'الحد الأدنى للاستثمار هو {group.min_investment}'
            }), 400
        
        # إضافة المستخدم كعضو في المجموعة
        membership = GroupMembership(
            user_id=user_id,
            group_id=group_id,
            role='member',
            investment_amount=investment_amount
        )
        
        db.session.add(membership)
        
        # تحديث المبلغ الحالي للمجموعة
        group.current_amount += investment_amount
        
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'تم الانضمام إلى المجموعة الاستثمارية بنجاح'
        }), 200
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error joining investment group: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': 'حدث خطأ أثناء الانضمام إلى المجموعة الاستثمارية'
        }), 500

# مغادرة مجموعة استثمارية
@investment_groups_bp.route('/<int:group_id>/leave', methods=['POST'])
@jwt_required()
def leave_group(group_id):
    try:
        user_id = get_jwt_identity()
        
        membership = GroupMembership.query.filter_by(user_id=user_id, group_id=group_id).first()
        
        if not membership:
            return jsonify({
                'status': 'error',
                'message': 'أنت لست عضواً في هذه المجموعة'
            }), 404
        
        # التحقق من أن المستخدم ليس قائد المجموعة
        if membership.role == 'leader':
            # التحقق من وجود أعضاء آخرين
            other_members = GroupMembership.query.filter(
                GroupMembership.group_id == group_id,
                GroupMembership.user_id != user_id
            ).count()
            
            if other_members > 0:
                return jsonify({
                    'status': 'error',
                    'message': 'لا يمكن لقائد المجموعة المغادرة طالما هناك أعضاء آخرين'
                }), 400
        
        # تحديث المبلغ الحالي للمجموعة
        group = InvestmentGroup.query.get(group_id)
        group.current_amount -= membership.investment_amount
        
        # حذف العضوية
        db.session.delete(membership)
        
        # إذا كان المستخدم هو قائد المجموعة وليس هناك أعضاء آخرين، يتم حذف المجموعة
        if membership.role == 'leader':
            db.session.delete(group)
        
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'تم مغادرة المجموعة الاستثمارية بنجاح'
        }), 200
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error leaving investment group: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': 'حدث خطأ أثناء مغادرة المجموعة الاستثمارية'
        }), 500

# إنشاء تصويت جديد
@investment_groups_bp.route('/<int:group_id>/votes', methods=['POST'])
@jwt_required()
def create_vote(group_id):
    try:
        user_id = get_jwt_identity()
        data = request.get_json()
        
        # التحقق من أن المستخدم عضو في المجموعة
        membership = GroupMembership.query.filter_by(user_id=user_id, group_id=group_id).first()
        
        if not membership:
            return jsonify({
                'status': 'error',
                'message': 'أنت لست عضواً في هذه المجموعة'
            }), 403
        
        # التحقق من البيانات المطلوبة
        required_fields = ['title', 'description', 'vote_type', 'end_date']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'status': 'error',
                    'message': f'حقل {field} مطلوب'
                }), 400
        
        # التحقق من تاريخ انتهاء التصويت
        end_date = datetime.fromisoformat(data['end_date'].replace('Z', '+00:00'))
        
        if end_date <= datetime.utcnow():
            return jsonify({
                'status': 'error',
                'message': 'تاريخ انتهاء التصويت يجب أن يكون في المستقبل'
            }), 400
        
        # إنشاء التصويت
        new_vote = GroupVote(
            group_id=group_id,
            title=data['title'],
            description=data['description'],
            vote_type=data['vote_type'],
            reference_id=data.get('reference_id'),
            end_date=end_date,
            created_by=user_id
        )
        
        db.session.add(new_vote)
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'تم إنشاء التصويت بنجاح',
            'data': {
                'id': new_vote.id,
                'title': new_vote.title
            }
        }), 201
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error creating vote: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': 'حدث خطأ أثناء إنشاء التصويت'
        }), 500

# التصويت
@investment_groups_bp.route('/votes/<int:vote_id>/respond', methods=['POST'])
@jwt_required()
def respond_to_vote(vote_id):
    try:
        user_id = get_jwt_identity()
        data = request.get_json()
        
        vote = GroupVote.query.get(vote_id)
        
        if not vote:
            return jsonify({
                'status': 'error',
                'message': 'التصويت غير موجود'
            }), 404
        
        # التحقق من أن التصويت نشط
        if vote.status != 'active':
            return jsonify({
                'status': 'error',
                'message': 'التصويت غير نشط'
            }), 400
        
        # التحقق من أن التصويت لم ينته
        if vote.end_date <= datetime.utcnow():
            return jsonify({
                'status': 'error',
                'message': 'انتهت مدة التصويت'
            }), 400
        
        # التحقق من أن المستخدم عضو في المجموعة
        membership = GroupMembership.query.filter_by(user_id=user_id, group_id=vote.group_id).first()
        
        if not membership:
            return jsonify({
                'status': 'error',
                'message': 'أنت لست عضواً في هذه المجموعة'

(Content truncated due to size limit. Use line ranges to read in chunks)