import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import MainLayout from '../layouts/MainLayout';

const AboutPage: React.FC = () => {
  return (
    <MainLayout>
      {/* قسم الترويسة */}
      <section className="bg-gradient-to-r from-primary/10 to-primary/5 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">من نحن</h1>
            <p className="text-xl md:text-2xl mb-6">منصة تمكين - الجسر الآمن بين المغترب وبلده</p>
            <p className="text-gray-700 max-w-3xl mx-auto">
              منصة استثمارية تربط المغتربين بفرص استثمارية في بلدانهم الأصلية، وتساهم في التنمية المستدامة وتعزيز الاقتصاد المحلي.
            </p>
          </div>
        </div>
      </section>

      {/* قسم قصتنا */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <img 
                src="/assets/images/about-story.jpg" 
                alt="قصة منصة تمكين" 
                className="rounded-lg shadow-xl"
              />
            </div>
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-6 text-primary">قصتنا</h2>
              <p className="text-gray-700 mb-4">
                بدأت فكرة منصة تمكين من تجربة شخصية لمؤسسها الذي كان مغترباً لسنوات طويلة، وواجه تحديات في إيجاد فرص استثمارية موثوقة في بلده الأصلي. ومن هنا، ولدت فكرة إنشاء منصة تربط المغتربين بفرص استثمارية حقيقية وآمنة في بلدانهم.
              </p>
              <p className="text-gray-700 mb-4">
                تأسست منصة تمكين في عام 2023، بهدف سد الفجوة بين المغتربين الذين يرغبون في الاستثمار في بلدانهم الأصلية، وبين أصحاب المشاريع الذين يبحثون عن تمويل لمشاريعهم. وخلال فترة قصيرة، نجحت المنصة في استقطاب آلاف المستثمرين وتمويل عشرات المشاريع في مختلف القطاعات.
              </p>
              <p className="text-gray-700">
                اليوم، تعد منصة تمكين واحدة من أسرع المنصات الاستثمارية نمواً في المنطقة، وتسعى لتوسيع نطاق عملها ليشمل المزيد من البلدان والقطاعات، وتحقيق رؤيتها في بناء جسر قوي يربط المغتربين ببلدانهم ويساهم في تحقيق التنمية المستدامة.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* قسم رؤيتنا ورسالتنا */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary">رؤيتنا ورسالتنا</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6 mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-4 text-center">رؤيتنا</h3>
              <p className="text-gray-700 text-center">
                أن نكون المنصة الاستثمارية الرائدة التي تربط المغتربين ببلدانهم الأصلية، وتساهم في تحقيق التنمية المستدامة وتعزيز الاقتصادات المحلية.
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6 mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-4 text-center">رسالتنا</h3>
              <p className="text-gray-700 text-center">
                توفير منصة آمنة وشفافة تتيح للمغتربين فرصاً استثمارية موثوقة في بلدانهم الأصلية، وتمكين أصحاب المشاريع من الحصول على التمويل اللازم لتنفيذ مشاريعهم، مما يساهم في خلق فرص عمل وتحقيق التنمية المستدامة.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* قسم قيمنا */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary">قيمنا</h2>
            <p className="text-gray-700 mt-4 max-w-3xl mx-auto">
              تستند منصة تمكين في عملها إلى مجموعة من القيم الأساسية التي تشكل هويتنا وتوجه قراراتنا وتعاملاتنا مع جميع الأطراف.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">الثقة والشفافية</h3>
              <p className="text-gray-700">
                نؤمن بأن الثقة هي أساس أي علاقة ناجحة، لذلك نلتزم بالشفافية الكاملة في جميع تعاملاتنا، ونوفر معلومات دقيقة وواضحة عن المشاريع والاستثمارات.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">الابتكار والتميز</h3>
              <p className="text-gray-700">
                نسعى دائماً لتقديم حلول مبتكرة وخدمات متميزة تلبي احتياجات المستثمرين وأصحاب المشاريع، ونعمل باستمرار على تطوير منصتنا وتحسين تجربة المستخدم.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">الأثر الاجتماعي</h3>
              <p className="text-gray-700">
                نؤمن بأن الاستثمار يجب أن يكون له أثر إيجابي على المجتمع، لذلك نركز على المشاريع التي تساهم في التنمية المستدامة وتحسين حياة الناس وخلق فرص عمل.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">التعاون والشراكة</h3>
              <p className="text-gray-700">
                نؤمن بقوة التعاون والشراكة، ونعمل على بناء علاقات قوية مع جميع الأطراف المعنية، من مستثمرين وأصحاب مشاريع وشركاء استراتيجيين، لتحقيق أهدافنا المشتركة.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">النزاهة والمسؤولية</h3>
              <p className="text-gray-700">
                نلتزم بأعلى معايير النزاهة والمسؤولية في جميع أعمالنا، ونتحمل مسؤولية قراراتنا وأفعالنا، ونسعى دائماً لتحقيق مصلحة جميع الأطراف.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">العدالة والشمولية</h3>
              <p className="text-gray-700">
                نؤمن بأهمية العدالة والشمولية، ونسعى لتوفير فرص متكافئة للجميع، بغض النظر عن خلفياتهم أو ظروفهم، ونعمل على تمكين الفئات المهمشة والمناطق الأقل حظاً.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* قسم فريقنا */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary">فريقنا</h2>
            <p className="text-gray-700 mt-4 max-w-3xl mx-auto">
              يضم فريق منصة تمكين نخبة من الخبراء والمتخصصين في مجالات الاستثمار والتكنولوجيا والتمويل، يجمعهم شغف مشترك لتحقيق رؤية المنصة ورسالتها.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <img 
                src="/assets/images/team1.jpg" 
                alt="أحمد محمد" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-1">أحمد محمد</h3>
                <p className="text-primary mb-3">المؤسس والرئيس التنفيذي</p>
                <p className="text-gray-700 mb-4">
                  خبرة أكثر من 15 عاماً في مجال الاستثمار والتمويل، عمل سابقاً في كبرى المؤسسات المالية العالمية.
                </p>
                <div className="flex space-x-4 space-x-reverse">
                  <a href="#" className="text-gray-500 hover:text-primary">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                    </svg>
                  </a>
                  <a href="#" className="text-gray-500 hover:text-primary">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path fillRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" clipRule="evenodd" />
                    </svg>
                  </a>
                  <a href="#" className="text-gray-500 hover:text-primary">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path fillRule="evenodd" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10c5.51 0 10-4.48 10-10S17.51 2 12 2zm6.605 4.61a8.502 8.502 0 011.93 5.314c-.281-.054-3.101-.629-5.943-.271-.065-.141-.12-.293-.184-.445a25.416 25.416 0 00-.564-1.236c3.145-1.28 4.577-3.124 4.761-3.362zM12 3.475c2.17 0 4.154.813 5.662 2.148-.152.216-1.443 1.941-4.48 3.08-1.399-2.57-2.95-4.675-3.189-5A8.687 8.687 0 0112 3.475zm-3.633.803a53.896 53.896 0 013.167 4.935c-3.992 1.063-7.517 1.04-7.896 1.04a8.581 8.581 0 014.729-5.975zM3.453 12.01v-.26c.37.01 4.512.065 8.775-1.215.25.477.477.965.694 1.453-.109.033-.228.065-.336.098-4.404 1.42-6.747 5.303-6.942 5.629a8.522 8.522 0 01-2.19-5.705zM12 20.547a8.482 8.482 0 01-5.239-1.8c.152-.315 1.888-3.656 6.703-5.337.022-.01.033-.01.054-.022a35.318 35.318 0 011.823 6.475 8.4 8.4 0 01-3.341.684zm4.761-1.465c-.086-.52-.542-3.015-1.659-6.084 2.679-.423 5.022.271 5.314.369a8.468 8.468 0 01-3.655 5.715z" clipRule="evenodd" />
                    </svg>
                  </a>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <img 
                src="/assets/images/team2.jpg" 
                alt="سارة علي" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-1">سارة علي</h3>
                <p className="text-primary mb-3">المدير المالي</p>
                <p className="text-gray-700 mb-4">
                  محاسبة قانونية معتمدة مع خبرة 10 سنوات في الإدارة المالية والاستثمار، عملت سابقاً في شركات استشارية عالمية.
                </p>
                <div className="flex space-x-4 space-x-reverse">
                  <a href="#" className="text-gray-500 hover:text-primary">
                    <svg className="w-5 h-5" fill="curre
(Content truncated due to size limit. Use line ranges to read in chunks)