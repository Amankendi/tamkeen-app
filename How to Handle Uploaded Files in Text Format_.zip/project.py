from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class ProjectCategory(db.Model):
    __tablename__ = 'project_categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=True)
    icon = db.Column(db.String(50), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    projects = db.relationship('Project', backref='category', lazy='dynamic')
    
    def __init__(self, name, description=None, icon=None):
        self.name = name
        self.description = description
        self.icon = icon
    
    def __repr__(self):
        return f'<ProjectCategory {self.name}>'


class Project(db.Model):
    __tablename__ = 'projects'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    short_description = db.Column(db.String(255), nullable=True)
    category_id = db.Column(db.Integer, db.ForeignKey('project_categories.id'), nullable=True)
    location = db.Column(db.String(100), nullable=True)
    country = db.Column(db.String(50), nullable=True)
    target_amount = db.Column(db.Numeric(15, 2), nullable=False)
    current_amount = db.Column(db.Numeric(15, 2), default=0)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=True)
    status = db.Column(db.String(20), nullable=False)  # active, completed, cancelled, pending
    risk_level = db.Column(db.String(20), nullable=True)
    expected_return = db.Column(db.Numeric(5, 2), nullable=True)
    min_investment = db.Column(db.Numeric(10, 2), nullable=True)
    featured = db.Column(db.Boolean, default=False)
    cover_image = db.Column(db.String(255), nullable=True)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    updates = db.relationship('ProjectUpdate', backref='project', lazy='dynamic', cascade='all, delete-orphan')
    documents = db.relationship('ProjectDocument', backref='project', lazy='dynamic', cascade='all, delete-orphan')
    impact_metrics = db.relationship('ImpactMetric', backref='project', lazy='dynamic', cascade='all, delete-orphan')
    investments = db.relationship('Investment', backref='project', lazy='dynamic')
    
    def __init__(self, title, description, target_amount, start_date, status):
        self.title = title
        self.description = description
        self.target_amount = target_amount
        self.start_date = start_date
        self.status = status
    
    def __repr__(self):
        return f'<Project {self.title}>'


class ProjectUpdate(db.Model):
    __tablename__ = 'project_updates'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id', ondelete='CASCADE'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text, nullable=False)
    update_date = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<ProjectUpdate {self.title} for Project {self.project_id}>'


class ProjectDocument(db.Model):
    __tablename__ = 'project_documents'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id', ondelete='CASCADE'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    file_path = db.Column(db.String(255), nullable=False)
    document_type = db.Column(db.String(50), nullable=True)
    is_public = db.Column(db.Boolean, default=True)
    uploaded_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<ProjectDocument {self.title} for Project {self.project_id}>'


class ImpactMetric(db.Model):
    __tablename__ = 'impact_metrics'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id', ondelete='CASCADE'), nullable=False)
    metric_name = db.Column(db.String(100), nullable=False)
    metric_value = db.Column(db.String(100), nullable=False)
    metric_unit = db.Column(db.String(50), nullable=True)
    measurement_date = db.Column(db.Date, nullable=True)
    description = db.Column(db.Text, nullable=True)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<ImpactMetric {self.metric_name} for Project {self.project_id}>'
