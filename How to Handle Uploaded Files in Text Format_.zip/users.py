from flask import Blueprint, jsonify, request
from src.models.user import db, User, UserProfile
from src.main import token_required
import datetime

users_bp = Blueprint('users', __name__)

@users_bp.route('/profile', methods=['GET'])
@token_required
def get_profile(current_user):
    profile = current_user.profile
    
    user_data = {
        'id': current_user.id,
        'username': current_user.username,
        'email': current_user.email,
        'roles': [role.name for role in current_user.roles],
        'is_verified': current_user.is_verified,
        'created_at': current_user.created_at.strftime('%Y-%m-%d %H:%M:%S')
    }
    
    if profile:
        user_data['profile'] = {
            'first_name': profile.first_name,
            'last_name': profile.last_name,
            'phone_number': profile.phone_number,
            'date_of_birth': profile.date_of_birth.strftime('%Y-%m-%d') if profile.date_of_birth else None,
            'gender': profile.gender,
            'nationality': profile.nationality,
            'address': profile.address,
            'city': profile.city,
            'country': profile.country,
            'postal_code': profile.postal_code,
            'bio': profile.bio,
            'profile_picture': profile.profile_picture
        }
    
    return jsonify(user_data), 200

@users_bp.route('/profile', methods=['PUT'])
@token_required
def update_profile(current_user):
    data = request.get_json()
    
    # Update user fields if provided
    if 'username' in data:
        # Check if username already exists
        existing_user = User.query.filter_by(username=data['username']).first()
        if existing_user and existing_user.id != current_user.id:
            return jsonify({'message': 'Username already exists!'}), 409
        
        current_user.username = data['username']
    
    if 'email' in data:
        # Check if email already exists
        existing_user = User.query.filter_by(email=data['email']).first()
        if existing_user and existing_user.id != current_user.id:
            return jsonify({'message': 'Email already exists!'}), 409
        
        current_user.email = data['email']
    
    # Get or create user profile
    profile = current_user.profile
    if not profile:
        profile = UserProfile(user_id=current_user.id)
        db.session.add(profile)
    
    # Update profile fields if provided
    profile_fields = [
        'first_name', 'last_name', 'phone_number', 'gender', 'nationality',
        'address', 'city', 'country', 'postal_code', 'bio', 'profile_picture'
    ]
    
    for field in profile_fields:
        if field in data:
            setattr(profile, field, data[field])
    
    # Handle date of birth separately
    if 'date_of_birth' in data and data['date_of_birth']:
        try:
            profile.date_of_birth = datetime.datetime.strptime(data['date_of_birth'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'message': 'Invalid date format for date_of_birth! Use YYYY-MM-DD.'}), 400
    
    db.session.commit()
    
    return jsonify({'message': 'Profile updated successfully!'}), 200

@users_bp.route('/change-password', methods=['POST'])
@token_required
def change_password(current_user):
    from werkzeug.security import generate_password_hash, check_password_hash
    
    data = request.get_json()
    
    if not data or not data.get('current_password') or not data.get('new_password'):
        return jsonify({'message': 'Current password and new password are required!'}), 400
    
    # Verify current password
    if not check_password_hash(current_user.password_hash, data['current_password']):
        return jsonify({'message': 'Current password is incorrect!'}), 401
    
    # Update password
    current_user.password_hash = generate_password_hash(data['new_password'], method='sha256')
    db.session.commit()
    
    return jsonify({'message': 'Password changed successfully!'}), 200

@users_bp.route('/notifications', methods=['GET'])
@token_required
def get_notifications(current_user):
    from src.models.system import Notification
    
    # Get pagination parameters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # Get user notifications with pagination
    notifications_pagination = Notification.query.filter_by(user_id=current_user.id).order_by(
        Notification.created_at.desc()
    ).paginate(page=page, per_page=per_page)
    
    # Format response
    notifications = []
    for notification in notifications_pagination.items:
        notifications.append({
            'id': notification.id,
            'title': notification.title,
            'message': notification.message,
            'type': notification.type,
            'is_read': notification.is_read,
            'related_entity_type': notification.related_entity_type,
            'related_entity_id': notification.related_entity_id,
            'created_at': notification.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify({
        'notifications': notifications,
        'total': notifications_pagination.total,
        'pages': notifications_pagination.pages,
        'current_page': notifications_pagination.page,
        'unread_count': Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
    }), 200

@users_bp.route('/notifications/mark-read', methods=['POST'])
@token_required
def mark_notifications_read(current_user):
    from src.models.system import Notification
    
    data = request.get_json()
    
    if 'notification_ids' in data and isinstance(data['notification_ids'], list):
        # Mark specific notifications as read
        for notification_id in data['notification_ids']:
            notification = Notification.query.filter_by(id=notification_id, user_id=current_user.id).first()
            if notification:
                notification.is_read = True
        
        db.session.commit()
        return jsonify({'message': 'Notifications marked as read!'}), 200
    else:
        # Mark all notifications as read
        Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
        db.session.commit()
        return jsonify({'message': 'All notifications marked as read!'}), 200
