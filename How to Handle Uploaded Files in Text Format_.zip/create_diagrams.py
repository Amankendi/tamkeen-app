import matplotlib.pyplot as plt
import numpy as np
import matplotlib
from matplotlib.patches import Rectangle
from matplotlib import font_manager
import os

# تعيين اللغة العربية
matplotlib.rcParams['font.family'] = 'Arial'
plt.rcParams['axes.unicode_minus'] = False

# إضافة الخطوط العربية
font_dirs = ['/usr/share/fonts/']
font_files = font_manager.findSystemFonts(fontpaths=font_dirs)
for font_file in font_files:
    font_manager.fontManager.addfont(font_file)

# تعيين الخط العربي
plt.rcParams['font.family'] = 'DejaVu Sans'

# إنشاء مجلد للرسومات
os.makedirs('/home/ubuntu/bank_union_project/images', exist_ok=True)

# 1. رسم بياني للهيكل التنظيمي
def create_org_chart():
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # تعطيل المحاور
    ax.axis('off')
    
    # إنشاء المستطيلات والنصوص
    entities = [
        {"name": "مؤسسة أمان - فرنسا", "x": 0.5, "y": 0.9, "width": 0.3, "height": 0.1, "color": "#1a5276"},
        {"name": "اتحاد المغتربين\nاليمنيين - هولندا", "x": 0.2, "y": 0.7, "width": 0.2, "height": 0.1, "color": "#2874a6"},
        {"name": "صحيفة الاتحاد\nفرنسا", "x": 0.45, "y": 0.7, "width": 0.2, "height": 0.1, "color": "#2874a6"},
        {"name": "منظمة أمان لدعم\nصغار المزارعين", "x": 0.7, "y": 0.7, "width": 0.2, "height": 0.1, "color": "#2874a6"},
        {"name": "شركة تمكين\nسلطنة عمان", "x": 0.2, "y": 0.5, "width": 0.2, "height": 0.1, "color": "#3498db"},
        {"name": "شركة بابا كاكاو\nالإكوادور", "x": 0.45, "y": 0.5, "width": 0.2, "height": 0.1, "color": "#3498db"},
        {"name": "شركة نيكسوفانس\nفرنسا", "x": 0.7, "y": 0.5, "width": 0.2, "height": 0.1, "color": "#3498db"},
        {"name": "بنك الاتحاد", "x": 0.4, "y": 0.3, "width": 0.3, "height": 0.1, "color": "#1abc9c"}
    ]
    
    # رسم المستطيلات والنصوص
    for entity in entities:
        rect = Rectangle((entity["x"], entity["y"]), entity["width"], entity["height"], 
                         facecolor=entity["color"], edgecolor='black', alpha=0.8)
        ax.add_patch(rect)
        ax.text(entity["x"] + entity["width"]/2, entity["y"] + entity["height"]/2, entity["name"], 
                ha='center', va='center', color='white', fontsize=10, fontweight='bold')
    
    # رسم الخطوط
    # من مؤسسة أمان إلى الكيانات الثلاثة
    ax.plot([0.65, 0.8], [0.9, 0.8], 'k-')
    ax.plot([0.65, 0.55], [0.9, 0.8], 'k-')
    ax.plot([0.65, 0.3], [0.9, 0.8], 'k-')
    
    # من الكيانات الثلاثة إلى الشركات الثلاثة
    ax.plot([0.3, 0.3], [0.7, 0.6], 'k-')
    ax.plot([0.55, 0.55], [0.7, 0.6], 'k-')
    ax.plot([0.8, 0.8], [0.7, 0.6], 'k-')
    
    # من الشركات الثلاثة إلى بنك الاتحاد
    ax.plot([0.3, 0.55], [0.5, 0.4], 'k-')
    ax.plot([0.55, 0.55], [0.5, 0.4], 'k-')
    ax.plot([0.8, 0.55], [0.5, 0.4], 'k-')
    
    plt.title('الهيكل التنظيمي لمشروع بنك الاتحاد', fontsize=16, fontweight='bold', pad=20)
    plt.savefig('/home/ubuntu/bank_union_project/images/org_chart.png', dpi=300, bbox_inches='tight')
    plt.close()

# 2. رسم بياني للتكلفة التأسيسية
def create_funding_chart():
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # البيانات
    categories = ['استثمار مؤسسي أولي', 'إصدار سندات مدعومة بأصول', 'منح وتبرعات تأسيسية']
    values = [45000, 60000, 45000]
    percentages = [30, 40, 30]
    colors = ['#3498db', '#2ecc71', '#e74c3c']
    
    # رسم الرسم البياني الدائري
    wedges, texts, autotexts = ax.pie(values, labels=None, autopct='%1.1f%%', 
                                     startangle=90, colors=colors)
    
    # تخصيص النص
    plt.setp(autotexts, size=10, weight='bold', color='white')
    
    # إضافة عنوان
    ax.set_title('التكلفة التأسيسية المتوقعة: 150,000 يورو', fontsize=14, fontweight='bold', pad=20)
    
    # إضافة مفتاح الرسم البياني
    ax.legend(wedges, [f'{cat} ({val:,} يورو, {pct}%)' for cat, val, pct in zip(categories, values, percentages)],
              loc='center left', bbox_to_anchor=(1, 0.5))
    
    plt.savefig('/home/ubuntu/bank_union_project/images/funding_chart.png', dpi=300, bbox_inches='tight')
    plt.close()

# 3. رسم بياني للجدول الزمني
def create_timeline_chart():
    fig, ax = plt.subplots(figsize=(12, 6))
    
    # البيانات
    phases = ['التحضير القانوني', 'التشغيل التجريبي', 'التوسع الإقليمي', 'إطلاق بنك الاتحاد']
    durations = [6, 6, 12, 6]  # بالأشهر
    starts = [0, 6, 12, 24]  # بداية كل مرحلة بالأشهر
    colors = ['#3498db', '#2ecc71', '#e74c3c', '#9b59b6']
    
    # رسم المخطط الزمني
    for i, (phase, duration, start, color) in enumerate(zip(phases, durations, starts, colors)):
        ax.barh(i, duration, left=start, color=color, alpha=0.8, edgecolor='black')
        ax.text(start + duration/2, i, phase, ha='center', va='center', color='white', fontweight='bold')
    
    # تخصيص المحاور
    ax.set_yticks([])
    ax.set_xticks(range(0, 31, 6))
    ax.set_xticklabels([f'{x} شهر' for x in range(0, 31, 6)])
    ax.set_xlabel('المدة الزمنية (بالأشهر)', fontsize=12)
    
    # إضافة عنوان
    ax.set_title('الجدول الزمني لتنفيذ مشروع بنك الاتحاد', fontsize=14, fontweight='bold', pad=20)
    
    # إضافة الشبكة
    ax.grid(axis='x', linestyle='--', alpha=0.7)
    
    plt.savefig('/home/ubuntu/bank_union_project/images/timeline_chart.png', dpi=300, bbox_inches='tight')
    plt.close()

# 4. رسم بياني لنموذج العمل
def create_business_model_chart():
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # تعطيل المحاور
    ax.axis('off')
    
    # إنشاء المستطيلات والنصوص
    entities = [
        {"name": "المغتربون", "x": 0.1, "y": 0.7, "width": 0.2, "height": 0.1, "color": "#3498db"},
        {"name": "اتحاد المغتربين", "x": 0.4, "y": 0.7, "width": 0.2, "height": 0.1, "color": "#2874a6"},
        {"name": "منصة تمكين", "x": 0.7, "y": 0.7, "width": 0.2, "height": 0.1, "color": "#1a5276"},
        
        {"name": "صحيفة الاتحاد", "x": 0.25, "y": 0.5, "width": 0.2, "height": 0.1, "color": "#e74c3c"},
        {"name": "مؤسسة أمان", "x": 0.55, "y": 0.5, "width": 0.2, "height": 0.1, "color": "#e67e22"},
        
        {"name": "المشاريع الزراعية", "x": 0.25, "y": 0.3, "width": 0.2, "height": 0.1, "color": "#2ecc71"},
        {"name": "بنك الاتحاد", "x": 0.55, "y": 0.3, "width": 0.2, "height": 0.1, "color": "#1abc9c"},
    ]
    
    # رسم المستطيلات والنصوص
    for entity in entities:
        rect = Rectangle((entity["x"], entity["y"]), entity["width"], entity["height"], 
                         facecolor=entity["color"], edgecolor='black', alpha=0.8)
        ax.add_patch(rect)
        ax.text(entity["x"] + entity["width"]/2, entity["y"] + entity["height"]/2, entity["name"], 
                ha='center', va='center', color='white', fontsize=10, fontweight='bold')
    
    # رسم الأسهم
    # من المغتربين إلى اتحاد المغتربين
    ax.annotate('', xy=(0.4, 0.75), xytext=(0.3, 0.75), 
                arrowprops=dict(facecolor='black', shrink=0.05, width=1.5, headwidth=8))
    
    # من اتحاد المغتربين إلى منصة تمكين
    ax.annotate('', xy=(0.7, 0.75), xytext=(0.6, 0.75), 
                arrowprops=dict(facecolor='black', shrink=0.05, width=1.5, headwidth=8))
    
    # من منصة تمكين إلى مؤسسة أمان
    ax.annotate('', xy=(0.65, 0.6), xytext=(0.75, 0.7), 
                arrowprops=dict(facecolor='black', shrink=0.05, width=1.5, headwidth=8))
    
    # من اتحاد المغتربين إلى صحيفة الاتحاد
    ax.annotate('', xy=(0.35, 0.6), xytext=(0.45, 0.7), 
                arrowprops=dict(facecolor='black', shrink=0.05, width=1.5, headwidth=8))
    
    # من مؤسسة أمان إلى المشاريع الزراعية
    ax.annotate('', xy=(0.35, 0.4), xytext=(0.55, 0.5), 
                arrowprops=dict(facecolor='black', shrink=0.05, width=1.5, headwidth=8))
    
    # من مؤسسة أمان إلى بنك الاتحاد
    ax.annotate('', xy=(0.65, 0.4), xytext=(0.65, 0.5), 
                arrowprops=dict(facecolor='black', shrink=0.05, width=1.5, headwidth=8))
    
    # من المشاريع الزراعية إلى بنك الاتحاد
    ax.annotate('', xy=(0.55, 0.35), xytext=(0.45, 0.35), 
                arrowprops=dict(facecolor='black', shrink=0.05, width=1.5, headwidth=8))
    
    # إضافة النصوص التوضيحية
    ax.text(0.35, 0.78, "انضمام", ha='center', va='center', fontsize=8)
    ax.text(0.65, 0.78, "تحويل أموال", ha='center', va='center', fontsize=8)
    ax.text(0.75, 0.65, "تمويل", ha='center', va='center', fontsize=8)
    ax.text(0.35, 0.65, "توعية", ha='center', va='center', fontsize=8)
    ax.text(0.45, 0.45, "دعم", ha='center', va='center', fontsize=8)
    ax.text(0.68, 0.45, "إشراف", ha='center', va='center', fontsize=8)
    ax.text(0.5, 0.38, "عوائد", ha='center', va='center', fontsize=8)
    
    plt.title('نموذج العمل التجاري لمشروع بنك الاتحاد', fontsize=16, fontweight='bold', pad=20)
    plt.savefig('/home/ubuntu/bank_union_project/images/business_model.png', dpi=300, bbox_inches='tight')
    plt.close()

# تنفيذ جميع الرسومات
create_org_chart()
create_funding_chart()
create_timeline_chart()
create_business_model_chart()

print("تم إنشاء الرسومات التوضيحية بنجاح!")
