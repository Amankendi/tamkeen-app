import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import MainLayout from '../layouts/MainLayout';
import { useAuth } from '../contexts/AuthContext';

const InvestmentGroupsPage: React.FC = () => {
  const [groups, setGroups] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    const fetchData = async () => {
      try {
        // محاكاة طلب API للمجموعات الاستثمارية
        setTimeout(() => {
          const mockGroups = [
            {
              id: 1,
              name: "مجموعة الاستثمار الزراعي",
              description: "مجموعة متخصصة في الاستثمار في المشاريع الزراعية المستدامة في المناطق الريفية",
              image: "/assets/images/group1.jpg",
              min_investment: 1000,
              target_amount: 100000,
              current_amount: 65000,
              status: "active",
              members_count: 24,
              created_at: "2025-01-10T08:30:00Z",
              project: "مشروع زراعة الكاكاو العضوي",
              category: "زراعي"
            },
            {
              id: 2,
              name: "مجموعة تمويل المشاريع التعليمية",
              description: "مجموعة تهدف إلى دعم المشاريع التعليمية في المناطق النائية وتوفير فرص تعليمية للأطفال",
              image: "/assets/images/group2.jpg",
              min_investment: 500,
              target_amount: 75000,
              current_amount: 45000,
              status: "active",
              members_count: 32,
              created_at: "2025-01-15T10:15:00Z",
              project: "مركز تدريب تقني",
              category: "تعليمي"
            },
            {
              id: 3,
              name: "مجموعة الطاقة المتجددة",
              description: "مجموعة استثمارية متخصصة في مشاريع الطاقة المتجددة والحلول البيئية المستدامة",
              image: "/assets/images/group3.jpg",
              min_investment: 2000,
              target_amount: 150000,
              current_amount: 90000,
              status: "active",
              members_count: 18,
              created_at: "2025-01-20T14:45:00Z",
              project: "مشروع الطاقة الشمسية للمناطق الريفية",
              category: "صناعي"
            },
            {
              id: 4,
              name: "مجموعة المشاريع الصحية",
              description: "مجموعة تستثمر في المشاريع الصحية والطبية لتحسين الخدمات الصحية في المناطق المحرومة",
              image: "/assets/images/group4.jpg",
              min_investment: 1500,
              target_amount: 120000,
              current_amount: 36000,
              status: "active",
              members_count: 15,
              created_at: "2025-01-25T09:30:00Z",
              project: "عيادة متنقلة للمناطق النائية",
              category: "صحي"
            },
            {
              id: 5,
              name: "مجموعة التكنولوجيا والابتكار",
              description: "مجموعة تدعم المشاريع التكنولوجية والابتكارات الرقمية في العالم العربي",
              image: "/assets/images/group5.jpg",
              min_investment: 3000,
              target_amount: 200000,
              current_amount: 150000,
              status: "active",
              members_count: 28,
              created_at: "2025-01-30T11:20:00Z",
              project: "تطبيق تعليمي للأطفال",
              category: "تقني"
            },
            {
              id: 6,
              name: "مجموعة المشاريع التجارية",
              description: "مجموعة تستثمر في المشاريع التجارية الصغيرة والمتوسطة لدعم رواد الأعمال",
              image: "/assets/images/group6.jpg",
              min_investment: 1000,
              target_amount: 80000,
              current_amount: 60000,
              status: "active",
              members_count: 22,
              created_at: "2025-02-05T13:10:00Z",
              project: "متجر إلكتروني للمنتجات المحلية",
              category: "تجاري"
            }
          ];
          
          setGroups(mockGroups);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // تصفية المجموعات حسب الفئة والبحث
  const filteredGroups = groups.filter(group => {
    const matchesCategory = activeCategory ? group.category === activeCategory : true;
    const matchesSearch = group.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          group.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // استخراج الفئات الفريدة
  const categories = Array.from(new Set(groups.map(group => group.category)));

  return (
    <MainLayout>
      <div className="bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold mb-4 text-primary">المجتمع الاستثماري التعاوني</h1>
            <p className="text-gray-700 max-w-3xl mx-auto">
              انضم إلى مجموعات استثمارية تعاونية تمكنك من المشاركة في مشاريع كبيرة مع مستثمرين آخرين، وتقليل المخاطر من خلال توزيعها على المجموعة.
            </p>
          </div>
          
          {/* شريط البحث */}
          <div className="mb-8">
            <div className="max-w-md mx-auto">
              <div className="relative">
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                  </svg>
                </div>
                <input
                  type="search"
                  className="block w-full p-4 pr-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-white focus:ring-primary focus:border-primary"
                  placeholder="ابحث عن مجموعات استثمارية..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </div>
          
          {/* فئات المجموعات */}
          <div className="mb-8">
            <div className="flex flex-wrap justify-center gap-2">
              <button
                className={`px-4 py-2 rounded-full text-sm font-medium ${activeCategory === null ? 'bg-primary text-white' : 'bg-white text-gray-700 hover:bg-gray-100'}`}
                onClick={() => setActiveCategory(null)}
              >
                الكل
              </button>
              {categories.map(category => (
                <button
                  key={category}
                  className={`px-4 py-2 rounded-full text-sm font-medium ${activeCategory === category ? 'bg-primary text-white' : 'bg-white text-gray-700 hover:bg-gray-100'}`}
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          
          {/* قائمة المجموعات */}
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : filteredGroups.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredGroups.map(group => (
                <div key={group.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                  <img 
                    src={group.image} 
                    alt={group.name} 
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <div className="flex justify-between items-center mb-2">
                      <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">{group.category}</span>
                      <span className="text-gray-500 text-sm">{group.members_count} عضو</span>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{group.name}</h3>
                    <p className="text-gray-600 mb-4 line-clamp-2">
                      {group.description}
                    </p>
                    <div className="mb-4">
                      <div className="flex justify-between mb-1">
                        <span className="text-gray-700">التمويل</span>
                        <span className="text-primary font-medium">{Math.round((group.current_amount / group.target_amount) * 100)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-primary h-2.5 rounded-full" style={{ width: `${(group.current_amount / group.target_amount) * 100}%` }}></div>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">الحد الأدنى: ${group.min_investment.toLocaleString()}</span>
                      <Link to={`/investment-groups/${group.id}`} className="btn btn-sm btn-primary">
                        تفاصيل
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold mb-4">لا توجد مجموعات</h2>
              <p className="mb-6">لم يتم العثور على مجموعات استثمارية تطابق معايير البحث.</p>
              <button 
                onClick={() => {
                  setActiveCategory(null);
                  setSearchTerm('');
                }}
                className="btn btn-primary"
              >
                عرض جميع المجموعات
              </button>
            </div>
          )}
          
          {/* إنشاء مجموعة جديدة */}
          <div className="mt-16 bg-primary text-white rounded-lg p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">هل تريد إنشاء مجموعة استثمارية خاصة بك؟</h2>
            <p className="mb-6 max-w-2xl mx-auto">
              يمكنك إنشاء مجموعة استثمارية خاصة بك ودعوة أصدقائك وزملائك للانضمام إليها والاستثمار معاً في المشاريع التي تهمكم.
            </p>
            {isAuthenticated ? (
              <Link to="/investment-groups/create" className="btn bg-white text-primary hover:bg-gray-100">
                إنشاء مجموعة جديدة
              </Link>
            ) : (
              <div className="flex flex-wrap justify-center gap-4">
                <Link to="/register" className="btn bg-white text-primary hover:bg-gray-100">
                  إنشاء حساب
                </Link>
                <Link to="/login" className="btn btn-outline border-white text-white hover:bg-white hover:text-primary">
                  تسجيل الدخول
                </Link>
              </div>
            )}
          </div>
          
          {/* مميزات المجتمع الاستثماري */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold mb-8 text-center">مميزات المجتمع الاستثماري التعاوني</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">استثمار بمبالغ صغيرة</h3>
                <p className="text-gray-700">
                  يمكنك المشاركة في مشاريع كبيرة بمبالغ صغيرة، مما يتيح لك فرصة الاستثمار في مشاريع متنوعة وتوزيع مخاطر الاستثمار.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656.126-1.283.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656-.126-1.283-.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">قوة المجتمع</h3>
                <p className="text-gray-700">
                  الاستفادة من خبرات وآراء أعضاء المجموعة في اتخاذ قرارات استثمارية أفضل، والتعلم من تجارب الآخرين وتبادل المعرفة.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">شفافية وديمقراطية</h3>
                <p className="text-gray-700">
                  نظام تصويت شفاف يتيح لجميع أعضاء المجموعة المشاركة في اتخاذ القرارات المتعلقة بالاستثمارات والمشاريع التي تدعمها المجموعة.
                </p>
              </div>
            </div>
          </div>
          
          {/* الأسئلة الشائعة */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold mb-8 text-center">الأسئلة الشائعة</h2>
            <div className="max-w-3xl mx-auto space-y-4">
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h3 className="text-lg font-semibold mb-2">كيف يمكنني الانضمام إلى مجموعة استثمارية؟</h3>
                <p className="text-gray-700">
                  يمكنك الانضمام إلى أي مجموعة استثمارية من خلال زيارة صفحة تفاصيل المجموعة والنقر على زر "انضمام"، ثم تحديد مبلغ الاستثمار الذي ترغب في المساهمة به.
                </p>
              </div>
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h3 className="text-lg font-semibold mb-2">كيف يتم اتخاذ القرارات في المجموعة الاستثمارية؟</h3>
                <p className="text-gray-700">
                  يتم اتخاذ القرارات في المجموعة من خلال نظام تصويت ديمقراطي، حيث يمكن لقائد المجموعة أو أي عضو فيها إنشاء تصويت حول قرار معين، ويتم اتخاذ القرار بناءً على نتيجة التصويت.
                </p>
              </div>
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h3 className="text-lg font-semibold mb-2">هل يمكنني الانسحاب من المجموعة واسترداد استثماري؟</h3>
                <p className="text-gray-700">
                  نعم، يمكنك الانسحاب من المجموعة في أي وقت واسترداد استثمارك إذا لم يتم استثماره بعد في أي مشروع. أما إذا تم استثمار المبلغ بالفعل، فيمكنك استرداده وفقاً لشروط المشروع وسياسة الاسترداد الخاصة به.
                </p>
              </div>
   
(Content truncated due to size limit. Use line ranges to read in chunks)