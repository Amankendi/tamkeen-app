from flask import Blueprint, jsonify, request
from src.models.project import db, Project, ProjectCategory, ProjectUpdate, ProjectDocument, ImpactMetric
from src.main import token_required
import datetime

projects_bp = Blueprint('projects', __name__)

@projects_bp.route('/', methods=['GET'])
def get_projects():
    # Get query parameters for filtering
    category = request.args.get('category')
    country = request.args.get('country')
    status = request.args.get('status')
    featured = request.args.get('featured')
    
    # Start with base query
    query = Project.query
    
    # Apply filters if provided
    if category:
        query = query.filter(Project.category_id == category)
    if country:
        query = query.filter(Project.country == country)
    if status:
        query = query.filter(Project.status == status)
    if featured and featured.lower() == 'true':
        query = query.filter(Project.featured == True)
    
    # Get pagination parameters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # Execute query with pagination
    projects_pagination = query.order_by(Project.created_at.desc()).paginate(page=page, per_page=per_page)
    
    # Format response
    projects = []
    for project in projects_pagination.items:
        category = ProjectCategory.query.get(project.category_id) if project.category_id else None
        
        projects.append({
            'id': project.id,
            'title': project.title,
            'short_description': project.short_description,
            'category': category.name if category else None,
            'location': project.location,
            'country': project.country,
            'target_amount': float(project.target_amount),
            'current_amount': float(project.current_amount),
            'funding_percentage': round((float(project.current_amount) / float(project.target_amount)) * 100, 2) if float(project.target_amount) > 0 else 0,
            'start_date': project.start_date.strftime('%Y-%m-%d') if project.start_date else None,
            'end_date': project.end_date.strftime('%Y-%m-%d') if project.end_date else None,
            'status': project.status,
            'risk_level': project.risk_level,
            'expected_return': float(project.expected_return) if project.expected_return else None,
            'min_investment': float(project.min_investment) if project.min_investment else None,
            'featured': project.featured,
            'cover_image': project.cover_image,
            'created_at': project.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify({
        'projects': projects,
        'total': projects_pagination.total,
        'pages': projects_pagination.pages,
        'current_page': projects_pagination.page
    }), 200

@projects_bp.route('/<int:project_id>', methods=['GET'])
def get_project(project_id):
    project = Project.query.get_or_404(project_id)
    category = ProjectCategory.query.get(project.category_id) if project.category_id else None
    
    # Get project updates
    updates = []
    for update in project.updates.order_by(ProjectUpdate.update_date.desc()).all():
        updates.append({
            'id': update.id,
            'title': update.title,
            'content': update.content,
            'update_date': update.update_date.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    # Get project documents
    documents = []
    for document in project.documents.filter_by(is_public=True).all():
        documents.append({
            'id': document.id,
            'title': document.title,
            'description': document.description,
            'document_type': document.document_type,
            'file_path': document.file_path
        })
    
    # Get impact metrics
    impact_metrics = []
    for metric in project.impact_metrics.all():
        impact_metrics.append({
            'id': metric.id,
            'metric_name': metric.metric_name,
            'metric_value': metric.metric_value,
            'metric_unit': metric.metric_unit,
            'description': metric.description
        })
    
    return jsonify({
        'id': project.id,
        'title': project.title,
        'description': project.description,
        'short_description': project.short_description,
        'category': category.name if category else None,
        'category_id': project.category_id,
        'location': project.location,
        'country': project.country,
        'target_amount': float(project.target_amount),
        'current_amount': float(project.current_amount),
        'funding_percentage': round((float(project.current_amount) / float(project.target_amount)) * 100, 2) if float(project.target_amount) > 0 else 0,
        'start_date': project.start_date.strftime('%Y-%m-%d') if project.start_date else None,
        'end_date': project.end_date.strftime('%Y-%m-%d') if project.end_date else None,
        'status': project.status,
        'risk_level': project.risk_level,
        'expected_return': float(project.expected_return) if project.expected_return else None,
        'min_investment': float(project.min_investment) if project.min_investment else None,
        'featured': project.featured,
        'cover_image': project.cover_image,
        'created_at': project.created_at.strftime('%Y-%m-%d %H:%M:%S'),
        'updates': updates,
        'documents': documents,
        'impact_metrics': impact_metrics
    }), 200

@projects_bp.route('/categories', methods=['GET'])
def get_categories():
    categories = ProjectCategory.query.all()
    
    result = []
    for category in categories:
        result.append({
            'id': category.id,
            'name': category.name,
            'description': category.description,
            'icon': category.icon
        })
    
    return jsonify({'categories': result}), 200

@projects_bp.route('/', methods=['POST'])
@token_required
def create_project(current_user):
    # Check if user has project_manager or admin role
    has_permission = False
    for role in current_user.roles:
        if role.name in ['admin', 'project_manager']:
            has_permission = True
            break
    
    if not has_permission:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    data = request.get_json()
    
    # Check required fields
    required_fields = ['title', 'description', 'target_amount', 'start_date', 'status']
    for field in required_fields:
        if field not in data:
            return jsonify({'message': f'Field {field} is required!'}), 400
    
    # Parse date fields
    try:
        start_date = datetime.datetime.strptime(data['start_date'], '%Y-%m-%d').date()
        end_date = datetime.datetime.strptime(data['end_date'], '%Y-%m-%d').date() if 'end_date' in data and data['end_date'] else None
    except ValueError:
        return jsonify({'message': 'Invalid date format! Use YYYY-MM-DD.'}), 400
    
    # Create new project
    new_project = Project(
        title=data['title'],
        description=data['description'],
        target_amount=data['target_amount'],
        start_date=start_date,
        status=data['status']
    )
    
    # Set optional fields
    if 'short_description' in data:
        new_project.short_description = data['short_description']
    if 'category_id' in data:
        new_project.category_id = data['category_id']
    if 'location' in data:
        new_project.location = data['location']
    if 'country' in data:
        new_project.country = data['country']
    if end_date:
        new_project.end_date = end_date
    if 'risk_level' in data:
        new_project.risk_level = data['risk_level']
    if 'expected_return' in data:
        new_project.expected_return = data['expected_return']
    if 'min_investment' in data:
        new_project.min_investment = data['min_investment']
    if 'featured' in data:
        new_project.featured = data['featured']
    if 'cover_image' in data:
        new_project.cover_image = data['cover_image']
    
    new_project.created_by = current_user.id
    
    db.session.add(new_project)
    db.session.commit()
    
    return jsonify({
        'message': 'Project created successfully!',
        'project_id': new_project.id
    }), 201

@projects_bp.route('/<int:project_id>', methods=['PUT'])
@token_required
def update_project(current_user, project_id):
    # Check if user has project_manager or admin role
    has_permission = False
    for role in current_user.roles:
        if role.name in ['admin', 'project_manager']:
            has_permission = True
            break
    
    if not has_permission:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    project = Project.query.get_or_404(project_id)
    data = request.get_json()
    
    # Update fields if provided
    if 'title' in data:
        project.title = data['title']
    if 'description' in data:
        project.description = data['description']
    if 'short_description' in data:
        project.short_description = data['short_description']
    if 'category_id' in data:
        project.category_id = data['category_id']
    if 'location' in data:
        project.location = data['location']
    if 'country' in data:
        project.country = data['country']
    if 'target_amount' in data:
        project.target_amount = data['target_amount']
    if 'current_amount' in data:
        project.current_amount = data['current_amount']
    if 'start_date' in data:
        try:
            project.start_date = datetime.datetime.strptime(data['start_date'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'message': 'Invalid start_date format! Use YYYY-MM-DD.'}), 400
    if 'end_date' in data:
        if data['end_date']:
            try:
                project.end_date = datetime.datetime.strptime(data['end_date'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'message': 'Invalid end_date format! Use YYYY-MM-DD.'}), 400
        else:
            project.end_date = None
    if 'status' in data:
        project.status = data['status']
    if 'risk_level' in data:
        project.risk_level = data['risk_level']
    if 'expected_return' in data:
        project.expected_return = data['expected_return']
    if 'min_investment' in data:
        project.min_investment = data['min_investment']
    if 'featured' in data:
        project.featured = data['featured']
    if 'cover_image' in data:
        project.cover_image = data['cover_image']
    
    db.session.commit()
    
    return jsonify({'message': 'Project updated successfully!'}), 200

@projects_bp.route('/<int:project_id>/updates', methods=['POST'])
@token_required
def add_project_update(current_user, project_id):
    # Check if user has project_manager or admin role
    has_permission = False
    for role in current_user.roles:
        if role.name in ['admin', 'project_manager']:
            has_permission = True
            break
    
    if not has_permission:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    project = Project.query.get_or_404(project_id)
    data = request.get_json()
    
    # Check required fields
    if 'title' not in data or 'content' not in data:
        return jsonify({'message': 'Title and content are required!'}), 400
    
    # Create new update
    new_update = ProjectUpdate(
        project_id=project_id,
        title=data['title'],
        content=data['content'],
        created_by=current_user.id
    )
    
    db.session.add(new_update)
    db.session.commit()
    
    return jsonify({
        'message': 'Project update added successfully!',
        'update_id': new_update.id
    }), 201

@projects_bp.route('/<int:project_id>/documents', methods=['POST'])
@token_required
def add_project_document(current_user, project_id):
    # Check if user has project_manager or admin role
    has_permission = False
    for role in current_user.roles:
        if role.name in ['admin', 'project_manager']:
            has_permission = True
            break
    
    if not has_permission:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    project = Project.query.get_or_404(project_id)
    data = request.get_json()
    
    # Check required fields
    if 'title' not in data or 'file_path' not in data:
        return jsonify({'message': 'Title and file_path are required!'}), 400
    
    # Create new document
    new_document = ProjectDocument(
        project_id=project_id,
        title=data['title'],
        file_path=data['file_path'],
        description=data.get('description'),
        document_type=data.get('document_type'),
        is_public=data.get('is_public', True),
        uploaded_by=current_user.id
    )
    
    db.session.add(new_document)
    db.session.commit()
    
    return jsonify({
        'message': 'Project document added successfully!',
        'document_id': new_document.id
    }), 201

@projects_bp.route('/<int:project_id>/impact', methods=['POST'])
@token_required
def add_impact_metric(current_user, project_id):
    # Check if user has project_manager or admin role
    has_permission = False
    for role in current_user.roles:
        if role.name in ['admin', 'project_manager']:
            has_permission = True
            break
    
    if not has_permission:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    project = Project.query.get_or_404(project_id)
    data = request.get_json()
    
    # Check required fields
    if 'metric_name' not in data or 'metric_value' not in data:
        return jsonify({'message': 'Metric name and value are required!'}), 400
    
    # Create new impact metric
    new_metric = ImpactMetric(
        project_id=project_id,
        metric_name=data['metric_name'],
        metric_value=data['metric_value'],
        metric_unit=data.get('metric_unit'),
        description=data.get('description'),
        created_by=current_user.id
    )
    
    if 'measurement_date' in data and data['measurement_date']:
        try:
            new_metric.measurement_date = datetime.datetime.strptime(data['measurement_date'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'message': 'Invalid measurement_date format! Use YYYY-MM-DD.'}), 400
    
    db.session.add(new_metric)
    db.session.commit()
    
    return jsonify({
        'message': 'Impact metric added successfully!',
        'metric_id': new_metric.id
    }), 201
