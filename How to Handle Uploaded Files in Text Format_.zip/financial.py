from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Transaction(db.Model):
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=True)
    transaction_type = db.Column(db.String(50), nullable=False)  # investment, withdrawal, transfer, fee
    amount = db.Column(db.Numeric(15, 2), nullable=False)
    currency = db.Column(db.String(10), default='EUR')
    status = db.Column(db.String(20), nullable=False)  # pending, completed, failed, cancelled
    payment_method = db.Column(db.String(50), nullable=True)
    transaction_reference = db.Column(db.String(100), unique=True, nullable=True)
    description = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('transactions', lazy='dynamic'))
    project = db.relationship('Project', backref=db.backref('transactions', lazy='dynamic'))
    investments = db.relationship('Investment', backref='transaction', lazy='dynamic')
    
    def __repr__(self):
        return f'<Transaction {self.id} - {self.transaction_type} - {self.amount}>'


class Investment(db.Model):
    __tablename__ = 'investments'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=True)
    transaction_id = db.Column(db.Integer, db.ForeignKey('transactions.id'), nullable=True)
    amount = db.Column(db.Numeric(15, 2), nullable=False)
    investment_date = db.Column(db.DateTime, default=datetime.utcnow)
    expected_return_rate = db.Column(db.Numeric(5, 2), nullable=True)
    status = db.Column(db.String(20), nullable=False)  # active, completed, cancelled
    return_amount = db.Column(db.Numeric(15, 2), nullable=True)
    return_date = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('investments', lazy='dynamic'))
    
    def __repr__(self):
        return f'<Investment {self.id} - User {self.user_id} - Project {self.project_id}>'


class PaymentMethod(db.Model):
    __tablename__ = 'payment_methods'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    method_type = db.Column(db.String(50), nullable=False)  # credit_card, bank_account, paypal, etc.
    provider = db.Column(db.String(50), nullable=True)
    account_number = db.Column(db.String(255), nullable=True)
    expiry_date = db.Column(db.String(10), nullable=True)
    is_default = db.Column(db.Boolean, default=False)
    is_verified = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('payment_methods', lazy='dynamic'))
    
    def __repr__(self):
        return f'<PaymentMethod {self.id} - {self.method_type} - User {self.user_id}>'


class Bond(db.Model):
    __tablename__ = 'bonds'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    total_value = db.Column(db.Numeric(15, 2), nullable=False)
    unit_price = db.Column(db.Numeric(10, 2), nullable=False)
    total_units = db.Column(db.Integer, nullable=False)
    available_units = db.Column(db.Integer, nullable=False)
    interest_rate = db.Column(db.Numeric(5, 2), nullable=False)
    maturity_period = db.Column(db.Integer, nullable=False)  # in months
    issue_date = db.Column(db.Date, nullable=False)
    maturity_date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(20), nullable=False)  # active, closed, cancelled
    backed_by = db.Column(db.String(100), nullable=True)  # asset backing the bond
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    purchases = db.relationship('BondPurchase', backref='bond', lazy='dynamic')
    
    def __repr__(self):
        return f'<Bond {self.id} - {self.title}>'


class BondPurchase(db.Model):
    __tablename__ = 'bond_purchases'
    
    id = db.Column(db.Integer, primary_key=True)
    bond_id = db.Column(db.Integer, db.ForeignKey('bonds.id'), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    transaction_id = db.Column(db.Integer, db.ForeignKey('transactions.id'), nullable=True)
    units_purchased = db.Column(db.Integer, nullable=False)
    purchase_amount = db.Column(db.Numeric(15, 2), nullable=False)
    purchase_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), nullable=False)  # active, matured, sold
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('bond_purchases', lazy='dynamic'))
    transaction = db.relationship('Transaction', backref=db.backref('bond_purchases', lazy='dynamic'))
    
    def __repr__(self):
        return f'<BondPurchase {self.id} - Bond {self.bond_id} - User {self.user_id}>'
