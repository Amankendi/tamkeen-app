import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import MainLayout from '../layouts/MainLayout';
import { useToast } from '../components/ui/use-toast';
import { useAuth } from '../contexts/AuthContext';

const ProjectDetailsPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [project, setProject] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [investmentAmount, setInvestmentAmount] = useState('');
  const { toast } = useToast();
  const { isAuthenticated, token } = useAuth();

  useEffect(() => {
    const fetchProject = async () => {
      try {
        // في الواقع، سنستخدم slug للبحث عن المشروع
        // لكن في هذا النموذج، سنستخدم بيانات وهمية
        
        // محاكاة طلب API
        setTimeout(() => {
          const mockProject = {
            id: 1,
            title: 'مشروع زراعة الكاكاو العضوي',
            slug: 'cacao-farming',
            description: 'مشروع لزراعة الكاكاو العضوي في الإكوادور، يهدف إلى دعم المزارعين المحليين وتحسين جودة الإنتاج. يستهدف المشروع زراعة 100 هكتار من أشجار الكاكاو العضوي، وتوفير فرص عمل لأكثر من 50 عائلة من صغار المزارعين. سيتم تطبيق أحدث التقنيات الزراعية المستدامة لضمان جودة المنتج وزيادة الإنتاجية.',
            short_description: 'مشروع لزراعة الكاكاو العضوي في الإكوادور، يهدف إلى دعم المزارعين المحليين وتحسين جودة الإنتاج.',
            category: 'زراعي',
            category_id: 1,
            location: 'مقاطعة إسميرالداس',
            country: 'الإكوادور',
            target_amount: 100000,
            current_amount: 80000,
            funding_percentage: 80,
            start_date: '2025-01-01',
            end_date: '2025-12-31',
            status: 'active',
            risk_level: 'متوسط',
            expected_return: 12,
            min_investment: 500,
            featured: true,
            cover_image: '/assets/images/project1.jpg',
            created_at: '2024-12-15 10:30:00',
            updates: [
              {
                id: 1,
                title: 'بدء المرحلة الأولى من المشروع',
                content: 'تم البدء في تنفيذ المرحلة الأولى من المشروع، والتي تشمل تجهيز الأرض وزراعة 30 هكتار من أشجار الكاكاو.',
                update_date: '2025-05-01 14:20:00'
              },
              {
                id: 2,
                title: 'اكتمال تمويل 50% من المشروع',
                content: 'نحن سعداء بإعلان اكتمال 50% من تمويل المشروع، ونشكر جميع المستثمرين على ثقتهم ودعمهم.',
                update_date: '2025-04-15 09:45:00'
              },
              {
                id: 3,
                title: 'إطلاق المشروع',
                content: 'تم إطلاق مشروع زراعة الكاكاو العضوي رسمياً، ونتطلع إلى تحقيق أهدافنا في دعم المزارعين المحليين وتحسين جودة الإنتاج.',
                update_date: '2025-04-01 11:30:00'
              }
            ],
            documents: [
              {
                id: 1,
                title: 'دراسة الجدوى',
                description: 'دراسة جدوى تفصيلية للمشروع',
                document_type: 'pdf',
                file_path: '/assets/documents/feasibility_study.pdf'
              },
              {
                id: 2,
                title: 'الخطة التنفيذية',
                description: 'خطة تنفيذ المشروع بالتفصيل',
                document_type: 'pdf',
                file_path: '/assets/documents/implementation_plan.pdf'
              },
              {
                id: 3,
                title: 'العقود والاتفاقيات',
                description: 'نماذج العقود والاتفاقيات مع المزارعين والموردين',
                document_type: 'pdf',
                file_path: '/assets/documents/contracts.pdf'
              }
            ],
            impact_metrics: [
              {
                id: 1,
                metric_name: 'فرص العمل',
                metric_value: '50',
                metric_unit: 'وظيفة',
                description: 'عدد فرص العمل التي سيوفرها المشروع'
              },
              {
                id: 2,
                metric_name: 'دعم المزارعين',
                metric_value: '20',
                metric_unit: 'أسرة',
                description: 'عدد أسر المزارعين المستفيدة من المشروع'
              },
              {
                id: 3,
                metric_name: 'تحسين الإنتاج',
                metric_value: '30',
                metric_unit: '%',
                description: 'نسبة تحسين الإنتاج الزراعي المتوقعة'
              }
            ]
          };
          
          setProject(mockProject);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Error fetching project:', error);
        toast({
          title: "خطأ في تحميل بيانات المشروع",
          description: "حدث خطأ أثناء تحميل بيانات المشروع. يرجى المحاولة مرة أخرى.",
          variant: "destructive",
        });
        setLoading(false);
      }
    };

    fetchProject();
  }, [slug, toast]);

  const handleInvestment = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isAuthenticated) {
      toast({
        title: "يرجى تسجيل الدخول",
        description: "يجب عليك تسجيل الدخول أولاً للاستثمار في هذا المشروع.",
        variant: "default",
      });
      return;
    }
    
    const amount = parseFloat(investmentAmount);
    
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "قيمة غير صالحة",
        description: "يرجى إدخال قيمة صالحة للاستثمار.",
        variant: "destructive",
      });
      return;
    }
    
    if (amount < project.min_investment) {
      toast({
        title: "قيمة أقل من الحد الأدنى",
        description: `الحد الأدنى للاستثمار هو ${project.min_investment} دولار.`,
        variant: "destructive",
      });
      return;
    }
    
    try {
      // محاكاة طلب API للاستثمار
      toast({
        title: "جاري معالجة طلب الاستثمار",
        description: "يرجى الانتظار...",
        variant: "default",
      });
      
      // في الواقع، سنرسل طلب API هنا
      setTimeout(() => {
        toast({
          title: "تم تقديم طلب الاستثمار بنجاح",
          description: `تم تقديم طلب استثمار بقيمة ${amount} دولار في مشروع ${project.title}. يمكنك متابعة حالة الطلب من لوحة التحكم.`,
          variant: "default",
        });
        setInvestmentAmount('');
      }, 1500);
    } catch (error) {
      console.error('Error submitting investment:', error);
      toast({
        title: "خطأ في تقديم طلب الاستثمار",
        description: "حدث خطأ أثناء تقديم طلب الاستثمار. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center min-h-[60vh]">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!project) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold mb-4">المشروع غير موجود</h2>
            <p className="mb-6">عذراً، لم يتم العثور على المشروع المطلوب.</p>
            <Link to="/projects" className="btn btn-primary">
              العودة إلى المشاريع
            </Link>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* رابط العودة */}
        <div className="mb-6">
          <Link to="/projects" className="text-gray-600 hover:text-primary flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
            العودة إلى المشاريع
          </Link>
        </div>
        
        {/* صورة المشروع */}
        <div className="mb-8">
          <img 
            src={project.cover_image} 
            alt={project.title} 
            className="w-full h-80 object-cover rounded-lg shadow-md"
          />
        </div>
        
        {/* معلومات المشروع الأساسية */}
        <div className="mb-8">
          <div className="flex flex-wrap items-center justify-between mb-4">
            <h1 className="text-3xl font-bold">{project.title}</h1>
            <div className="flex items-center mt-2 md:mt-0">
              <span className={`bg-green-100 text-green-800 text-sm font-medium px-2.5 py-0.5 rounded ml-2`}>
                {project.category}
              </span>
              <span className="text-gray-500 text-sm flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                {project.country}
              </span>
            </div>
          </div>
          
          {/* مؤشرات المشروع */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
              <h3 className="text-gray-500 text-sm mb-1">المبلغ المستهدف</h3>
              <p className="text-2xl font-bold text-primary">${project.target_amount.toLocaleString()}</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
              <h3 className="text-gray-500 text-sm mb-1">المستثمرين</h3>
              <p className="text-2xl font-bold text-primary">45</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
              <h3 className="text-gray-500 text-sm mb-1">الأيام المتبقية</h3>
              <p className="text-2xl font-bold text-primary">30</p>
            </div>
          </div>
          
          {/* شريط التقدم */}
          <div className="mb-6">
            <div className="flex justify-between mb-1">
              <span className="text-gray-700">التمويل</span>
              <span className="text-primary font-medium">{project.funding_percentage}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-primary h-2.5 rounded-full" 
                style={{ width: `${project.funding_percentage}%` }}
              ></div>
            </div>
          </div>
          
          {/* أزرار الإجراءات */}
          <div className="flex flex-wrap gap-4">
            <button 
              className="btn btn-primary"
              onClick={() => document.getElementById('investmentModal')?.classList.remove('hidden')}
            >
              استثمر الآن
            </button>
            <button className="btn btn-outline flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
              </svg>
              شارك المشروع
            </button>
          </div>
        </div>
        
        {/* وصف المشروع والتفاصيل */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            {/* وصف المشروع */}
            <div className="bg-white p-6 rounded-lg shadow-md mb-8">
              <h2 className="text-xl font-bold mb-4 border-r-4 border-primary pr-3">وصف المشروع</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                {project.description}
              </p>
            </div>
            
            {/* تحديثات المشروع */}
            <div className="bg-white p-6 rounded-lg shadow-md mb-8">
              <h2 className="text-xl font-bold mb-4 border-r-4 border-primary pr-3">تحديثات المشروع</h2>
              <div className="space-y-6">
                {project.updates.map((update: any) => (
                  <div key={update.id} className="border-r-2 border-gray-200 pr-4 relative">
                    <div className="w-3 h-3 bg-primary rounded-full absolute right-[-6.5px] top-1"></div>
                    <h3 className="font-semibold text-lg mb-1">{update.title}</h3>
                    <p className="text-gray-500 text-sm mb-2">{new Date(update.update_date).toLocaleDateString('ar-EG')}</p>
                    <p className="text-gray-700">{update.content}</p>
                  </div>
                ))}
              </div>
            </div>
            
            {/* الأثر الاجتماعي */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-bold mb-4 border-r-4 border-primary pr-3">الأثر الاجتماعي</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {project.impact_metrics.map((metric: any) => (
                  <div key={metric.id} className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">{metric.metric_name}</h3>
                    <p className="text-2xl font-bold text-primary mb-1">
                      {metric.metric_value} <span className="text-sm text-gray-500">{metric.metric_unit}</span>
                    </p>
                    <p className="text-gray-600 text-sm">{metric.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="md:col-span-1">
            {/* تفاصيل الاستثمار */}
            <div className="bg-white p-6 rounded-lg shadow-md mb-8">
              <h2 className="text-xl font-bold mb-4 border-r-4 border-primary pr-3">تفاصيل الاستثمار</h2>
              <ul className="space-y-3">
                <li className="flex justify-between">
                  <span className="text-gray-600">الحد الأدنى للاستثمار:</span>
                  <span className="font-medium">${project.min_investment}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">العائد المتوقع:</span>
                  <span className="font-medium">{project.expected_return}% سنوياً</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">مدة المشروع:</span>
                  <span className="font-medium">3 سنوات</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">مستوى المخاطرة:</span>
                  <span className="font-medium">{project.risk_level}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">تاريخ البدء:</span>
                  <span className="font-medium">{new Date(project.start_date).toLocaleDateString('ar-EG')}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">تاريخ الانتهاء:</span>
                  <span className="font-medium">{new Date(project.end_date).toLocaleDateString('ar-EG')}</span>
                </li>
              </ul>
            </div>
            
            {/* الوثائق والمستندات */}
            <div className="bg-white p-6 rounded-lg shadow-md mb-8">
     
(Content truncated due to size limit. Use line ranges to read in chunks)