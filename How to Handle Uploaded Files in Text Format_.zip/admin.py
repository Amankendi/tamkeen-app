from flask import Blueprint, jsonify, request
from src.models.user import db, User, Role, UserProfile
from src.models.project import Project, ProjectCategory
from src.models.financial import Transaction, Investment
from src.models.content import Article, ContentCategory
from src.main import token_required
import datetime

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/dashboard', methods=['GET'])
@token_required
def get_dashboard(current_user):
    # Check if user has admin role
    has_admin_role = False
    for role in current_user.roles:
        if role.name == 'admin':
            has_admin_role = True
            break
    
    if not has_admin_role:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    # Get system statistics
    total_users = User.query.count()
    total_projects = Project.query.count()
    total_investments = Investment.query.count()
    total_transactions = Transaction.query.count()
    
    # Get active projects amount
    active_projects_amount = db.session.query(db.func.sum(Project.current_amount)).filter(Project.status == 'active').scalar() or 0
    
    # Get recent users
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    recent_users_data = []
    for user in recent_users:
        recent_users_data.append({
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'created_at': user.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    # Get recent transactions
    recent_transactions = Transaction.query.order_by(Transaction.created_at.desc()).limit(5).all()
    recent_transactions_data = []
    for transaction in recent_transactions:
        recent_transactions_data.append({
            'id': transaction.id,
            'user_id': transaction.user_id,
            'transaction_type': transaction.transaction_type,
            'amount': float(transaction.amount),
            'status': transaction.status,
            'created_at': transaction.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    # Get project categories distribution
    categories = ProjectCategory.query.all()
    categories_data = []
    for category in categories:
        project_count = Project.query.filter_by(category_id=category.id).count()
        categories_data.append({
            'id': category.id,
            'name': category.name,
            'project_count': project_count
        })
    
    return jsonify({
        'statistics': {
            'total_users': total_users,
            'total_projects': total_projects,
            'total_investments': total_investments,
            'total_transactions': total_transactions,
            'active_projects_amount': float(active_projects_amount)
        },
        'recent_users': recent_users_data,
        'recent_transactions': recent_transactions_data,
        'categories': categories_data
    }), 200

@admin_bp.route('/users', methods=['GET'])
@token_required
def get_users(current_user):
    # Check if user has admin role
    has_admin_role = False
    for role in current_user.roles:
        if role.name == 'admin':
            has_admin_role = True
            break
    
    if not has_admin_role:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    # Get pagination parameters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # Get users with pagination
    users_pagination = User.query.order_by(User.created_at.desc()).paginate(page=page, per_page=per_page)
    
    # Format response
    users = []
    for user in users_pagination.items:
        users.append({
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'is_active': user.is_active,
            'is_verified': user.is_verified,
            'roles': [role.name for role in user.roles],
            'created_at': user.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'last_login': user.last_login.strftime('%Y-%m-%d %H:%M:%S') if user.last_login else None
        })
    
    return jsonify({
        'users': users,
        'total': users_pagination.total,
        'pages': users_pagination.pages,
        'current_page': users_pagination.page
    }), 200

@admin_bp.route('/users/<int:user_id>', methods=['GET'])
@token_required
def get_user(current_user, user_id):
    # Check if user has admin role
    has_admin_role = False
    for role in current_user.roles:
        if role.name == 'admin':
            has_admin_role = True
            break
    
    if not has_admin_role:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    user = User.query.get_or_404(user_id)
    profile = user.profile
    
    user_data = {
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'is_active': user.is_active,
        'is_verified': user.is_verified,
        'roles': [role.name for role in user.roles],
        'created_at': user.created_at.strftime('%Y-%m-%d %H:%M:%S'),
        'updated_at': user.updated_at.strftime('%Y-%m-%d %H:%M:%S'),
        'last_login': user.last_login.strftime('%Y-%m-%d %H:%M:%S') if user.last_login else None
    }
    
    if profile:
        user_data['profile'] = {
            'first_name': profile.first_name,
            'last_name': profile.last_name,
            'date_of_birth': profile.date_of_birth.strftime('%Y-%m-%d') if profile.date_of_birth else None,
            'gender': profile.gender,
            'nationality': profile.nationality,
            'address': profile.address,
            'city': profile.city,
            'country': profile.country,
            'postal_code': profile.postal_code,
            'bio': profile.bio,
            'profile_picture': profile.profile_picture
        }
    
    # Get user investments
    investments = Investment.query.filter_by(user_id=user_id).order_by(Investment.created_at.desc()).limit(5).all()
    investments_data = []
    for investment in investments:
        project = Project.query.get(investment.project_id) if investment.project_id else None
        investments_data.append({
            'id': investment.id,
            'project_id': investment.project_id,
            'project_title': project.title if project else None,
            'amount': float(investment.amount),
            'status': investment.status,
            'created_at': investment.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    user_data['recent_investments'] = investments_data
    
    # Get user transactions
    transactions = Transaction.query.filter_by(user_id=user_id).order_by(Transaction.created_at.desc()).limit(5).all()
    transactions_data = []
    for transaction in transactions:
        transactions_data.append({
            'id': transaction.id,
            'transaction_type': transaction.transaction_type,
            'amount': float(transaction.amount),
            'status': transaction.status,
            'created_at': transaction.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    user_data['recent_transactions'] = transactions_data
    
    return jsonify(user_data), 200

@admin_bp.route('/users/<int:user_id>/update-role', methods=['POST'])
@token_required
def update_user_role(current_user, user_id):
    # Check if user has admin role
    has_admin_role = False
    for role in current_user.roles:
        if role.name == 'admin':
            has_admin_role = True
            break
    
    if not has_admin_role:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    if 'roles' not in data or not isinstance(data['roles'], list):
        return jsonify({'message': 'Roles list is required!'}), 400
    
    # Clear existing roles
    user.roles = []
    
    # Add new roles
    for role_name in data['roles']:
        role = Role.query.filter_by(name=role_name).first()
        if role:
            user.roles.append(role)
    
    db.session.commit()
    
    return jsonify({
        'message': 'User roles updated successfully!',
        'roles': [role.name for role in user.roles]
    }), 200

@admin_bp.route('/users/<int:user_id>/toggle-status', methods=['POST'])
@token_required
def toggle_user_status(current_user, user_id):
    # Check if user has admin role
    has_admin_role = False
    for role in current_user.roles:
        if role.name == 'admin':
            has_admin_role = True
            break
    
    if not has_admin_role:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    user = User.query.get_or_404(user_id)
    
    # Toggle active status
    user.is_active = not user.is_active
    db.session.commit()
    
    return jsonify({
        'message': f'User {"activated" if user.is_active else "deactivated"} successfully!',
        'is_active': user.is_active
    }), 200

@admin_bp.route('/projects', methods=['GET'])
@token_required
def get_admin_projects(current_user):
    # Check if user has admin or project_manager role
    has_permission = False
    for role in current_user.roles:
        if role.name in ['admin', 'project_manager']:
            has_permission = True
            break
    
    if not has_permission:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    # Get pagination parameters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # Get projects with pagination
    projects_pagination = Project.query.order_by(Project.created_at.desc()).paginate(page=page, per_page=per_page)
    
    # Format response
    projects = []
    for project in projects_pagination.items:
        category = ProjectCategory.query.get(project.category_id) if project.category_id else None
        
        projects.append({
            'id': project.id,
            'title': project.title,
            'category': category.name if category else None,
            'target_amount': float(project.target_amount),
            'current_amount': float(project.current_amount),
            'funding_percentage': round((float(project.current_amount) / float(project.target_amount)) * 100, 2) if float(project.target_amount) > 0 else 0,
            'status': project.status,
            'featured': project.featured,
            'created_at': project.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify({
        'projects': projects,
        'total': projects_pagination.total,
        'pages': projects_pagination.pages,
        'current_page': projects_pagination.page
    }), 200

@admin_bp.route('/investments', methods=['GET'])
@token_required
def get_admin_investments(current_user):
    # Check if user has admin or financial_manager role
    has_permission = False
    for role in current_user.roles:
        if role.name in ['admin', 'financial_manager']:
            has_permission = True
            break
    
    if not has_permission:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    # Get pagination parameters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # Get investments with pagination
    investments_pagination = Investment.query.order_by(Investment.created_at.desc()).paginate(page=page, per_page=per_page)
    
    # Format response
    investments = []
    for investment in investments_pagination.items:
        user = User.query.get(investment.user_id) if investment.user_id else None
        project = Project.query.get(investment.project_id) if investment.project_id else None
        
        investments.append({
            'id': investment.id,
            'user_id': investment.user_id,
            'username': user.username if user else None,
            'project_id': investment.project_id,
            'project_title': project.title if project else None,
            'amount': float(investment.amount),
            'status': investment.status,
            'created_at': investment.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify({
        'investments': investments,
        'total': investments_pagination.total,
        'pages': investments_pagination.pages,
        'current_page': investments_pagination.page
    }), 200

@admin_bp.route('/transactions', methods=['GET'])
@token_required
def get_admin_transactions(current_user):
    # Check if user has admin or financial_manager role
    has_permission = False
    for role in current_user.roles:
        if role.name in ['admin', 'financial_manager']:
            has_permission = True
            break
    
    if not has_permission:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    # Get pagination parameters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # Get transactions with pagination
    transactions_pagination = Transaction.query.order_by(Transaction.created_at.desc()).paginate(page=page, per_page=per_page)
    
    # Format response
    transactions = []
    for transaction in transactions_pagination.items:
        user = User.query.get(transaction.user_id) if transaction.user_id else None
        project = Project.query.get(transaction.project_id) if transaction.project_id else None
        
        transactions.append({
            'id': transaction.id,
            'user_id': transaction.user_id,
            'username': user.username if user else None,
            'project_id': transaction.project_id,
            'project_title': project.title if project else None,
            'transaction_type': transaction.transaction_type,
            'amount': float(transaction.amount),
            'status': transaction.status,
            'created_at': transaction.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify({
        'transactions': transactions,
        'total': transactions_pagination.total,
        'pages': transactions_pagination.pages,
        'current_page': transactions_pagination.page
    }), 200

@admin_bp.route('/content', methods=['GET'])
@token_required
def get_admin_content(current_user):
    # Check if user has admin or editor role
    has_permission = False
    for role in current_user.roles:
        if role.name in ['admin', 'editor']:
            has_permission = True
            break
    
    if not has_permission:
        return jsonify({'message': 'Unauthorized access!'}), 403
    
    # Get pagination parameters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # Get articles with pagination
    articles_pagination = Article.query.order_by(Article.created_at.desc()).paginate(page=page, per_page=per_page)
    
    # Format response
    articles = []
    for article in articles_pagination.items:
        user = User.query.get(article.author_id) if article.author_id else None
        category = ContentCategory.query.get(article.category_id) if article.category_id else None
        
        articles.append({
            'id': article.id,
            'title': article.title,
            'slug': article.slug,
            'author': user.username if user else None,
            'category': category.name if category else None,
            'status': article.status,
            'published_at': article.published_at.strftime('%Y-%m-%d %H:%M:%S') if article.published_at else None,
            'created_at': article.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify({
        'articles': articles,
        'total': articles_pagination.total,
        'pages': articles_pagination.pages,
        'current_page': articles_pagination.page
    }), 200
