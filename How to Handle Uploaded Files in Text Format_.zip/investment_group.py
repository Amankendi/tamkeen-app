from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

# نموذج المجموعة الاستثمارية
class InvestmentGroup(db.Model):
    __tablename__ = 'investment_groups'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    image = db.Column(db.String(255))
    min_investment = db.Column(db.Float, nullable=False)
    target_amount = db.Column(db.Float, nullable=False)
    current_amount = db.Column(db.Float, default=0)
    status = db.Column(db.String(20), default='active')  # active, completed, cancelled
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات
    creator_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    creator = db.relationship('User', backref='created_groups', foreign_keys=[creator_id])
    
    # المشروع المرتبط بالمجموعة (إذا كان هناك مشروع محدد)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=True)
    project = db.relationship('Project', backref='investment_groups')
    
    # علاقة متعددة مع المستخدمين (الأعضاء)
    members = db.relationship('GroupMembership', back_populates='group')
    
    # علاقة متعددة مع المشاريع (إذا كانت المجموعة تستثمر في عدة مشاريع)
    investments = db.relationship('GroupInvestment', back_populates='group')
    
    # علاقة متعددة مع التصويتات
    votes = db.relationship('GroupVote', back_populates='group')
    
    def __repr__(self):
        return f'<InvestmentGroup {self.name}>'


# نموذج عضوية المجموعة
class GroupMembership(db.Model):
    __tablename__ = 'group_memberships'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    group_id = db.Column(db.Integer, db.ForeignKey('investment_groups.id'), nullable=False)
    role = db.Column(db.String(20), default='member')  # leader, member
    investment_amount = db.Column(db.Float, default=0)
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # العلاقات
    user = db.relationship('User', back_populates='group_memberships')
    group = db.relationship('InvestmentGroup', back_populates='members')
    
    __table_args__ = (
        db.UniqueConstraint('user_id', 'group_id', name='unique_user_group'),
    )
    
    def __repr__(self):
        return f'<GroupMembership {self.user_id} - {self.group_id}>'


# نموذج استثمارات المجموعة
class GroupInvestment(db.Model):
    __tablename__ = 'group_investments'
    
    id = db.Column(db.Integer, primary_key=True)
    group_id = db.Column(db.Integer, db.ForeignKey('investment_groups.id'), nullable=False)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, approved, completed, cancelled
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات
    group = db.relationship('InvestmentGroup', back_populates='investments')
    project = db.relationship('Project', backref='group_investments')
    
    def __repr__(self):
        return f'<GroupInvestment {self.group_id} - {self.project_id}>'


# نموذج التصويت في المجموعة
class GroupVote(db.Model):
    __tablename__ = 'group_votes'
    
    id = db.Column(db.Integer, primary_key=True)
    group_id = db.Column(db.Integer, db.ForeignKey('investment_groups.id'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    vote_type = db.Column(db.String(20), nullable=False)  # project_investment, member_removal, group_dissolution, etc.
    reference_id = db.Column(db.Integer)  # يمكن أن يكون معرف المشروع أو العضو حسب نوع التصويت
    status = db.Column(db.String(20), default='active')  # active, completed, cancelled
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime, nullable=False)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # العلاقات
    group = db.relationship('InvestmentGroup', back_populates='votes')
    creator = db.relationship('User', backref='created_votes')
    votes = db.relationship('VoteResponse', back_populates='vote')
    
    def __repr__(self):
        return f'<GroupVote {self.title}>'


# نموذج استجابة التصويت
class VoteResponse(db.Model):
    __tablename__ = 'vote_responses'
    
    id = db.Column(db.Integer, primary_key=True)
    vote_id = db.Column(db.Integer, db.ForeignKey('group_votes.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    response = db.Column(db.String(20), nullable=False)  # yes, no, abstain
    comment = db.Column(db.Text)
    voted_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # العلاقات
    vote = db.relationship('GroupVote', back_populates='votes')
    user = db.relationship('User', backref='vote_responses')
    
    __table_args__ = (
        db.UniqueConstraint('vote_id', 'user_id', name='unique_vote_user'),
    )
    
    def __repr__(self):
        return f'<VoteResponse {self.vote_id} - {self.user_id}>'
