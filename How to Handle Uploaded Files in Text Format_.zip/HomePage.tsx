import React from 'react';
import { Link } from 'react-router-dom';
import MainLayout from '../layouts/MainLayout';

const HomePage: React.FC = () => {
  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary/10 to-primary/5 py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">منصة تمكين</h1>
              <p className="text-xl md:text-2xl mb-6">الجسر الآمن بين المغترب وبلده</p>
              <p className="text-gray-700 mb-8">
                منصة استثمارية تربط المغتربين بفرص استثمارية في بلدانهم الأصلية، وتساهم في التنمية المستدامة وتعزيز الاقتصاد المحلي.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/projects" className="btn btn-primary">
                  استثمر الآن
                </Link>
                <Link to="/about" className="btn btn-outline">
                  تعرف علينا
                </Link>
              </div>
            </div>
            <div className="md:w-1/2">
              <img 
                src="/assets/images/hero-image.jpg" 
                alt="منصة تمكين" 
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">مجالات الاستثمار</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">المشاريع الزراعية</h3>
              <p className="text-gray-600">
                استثمر في مشاريع زراعية مستدامة تساهم في تحقيق الأمن الغذائي وتوفير فرص عمل للمجتمعات المحلية.
              </p>
              <Link to="/projects?category=1" className="text-primary font-medium mt-4 inline-block">
                عرض المشاريع
              </Link>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">المشاريع التجارية</h3>
              <p className="text-gray-600">
                فرص استثمارية في قطاع التجارة والخدمات، تساهم في تنشيط الاقتصاد المحلي وتلبية احتياجات السوق.
              </p>
              <Link to="/projects?category=6" className="text-primary font-medium mt-4 inline-block">
                عرض المشاريع
              </Link>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">المشاريع التقنية</h3>
              <p className="text-gray-600">
                استثمر في مشاريع تكنولوجية مبتكرة تساهم في تطوير البنية التحتية الرقمية وتعزيز الاقتصاد المعرفي.
              </p>
              <Link to="/projects?category=5" className="text-primary font-medium mt-4 inline-block">
                عرض المشاريع
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Projects Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">المشاريع المميزة</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Project cards will be dynamically loaded here */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <img 
                src="/assets/images/project1.jpg" 
                alt="مشروع زراعة الكاكاو العضوي" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">زراعي</span>
                  <span className="text-gray-500 text-sm">الإكوادور</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">مشروع زراعة الكاكاو العضوي</h3>
                <p className="text-gray-600 mb-4 line-clamp-2">
                  مشروع لزراعة الكاكاو العضوي في الإكوادور، يهدف إلى دعم المزارعين المحليين وتحسين جودة الإنتاج.
                </p>
                <div className="mb-4">
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-700">التمويل</span>
                    <span className="text-primary font-medium">80%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-primary h-2.5 rounded-full" style={{ width: '80%' }}></div>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-700">$100,000</span>
                  <Link to="/projects/cacao-farming" className="btn btn-sm btn-primary">
                    تفاصيل
                  </Link>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <img 
                src="/assets/images/project2.jpg" 
                alt="مشروع متجر إلكتروني للمنتجات المحلية" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">تجاري</span>
                  <span className="text-gray-500 text-sm">اليمن</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">متجر إلكتروني للمنتجات المحلية</h3>
                <p className="text-gray-600 mb-4 line-clamp-2">
                  منصة تجارة إلكترونية متخصصة في تسويق المنتجات اليدوية والتراثية اليمنية للأسواق العالمية.
                </p>
                <div className="mb-4">
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-700">التمويل</span>
                    <span className="text-primary font-medium">65%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-primary h-2.5 rounded-full" style={{ width: '65%' }}></div>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-700">$75,000</span>
                  <Link to="/projects/local-ecommerce" className="btn btn-sm btn-primary">
                    تفاصيل
                  </Link>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <img 
                src="/assets/images/project3.jpg" 
                alt="مشروع مركز تدريب تقني" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="bg-purple-100 text-purple-800 text-xs font-medium px-2.5 py-0.5 rounded">تعليمي</span>
                  <span className="text-gray-500 text-sm">الأردن</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">مركز تدريب تقني</h3>
                <p className="text-gray-600 mb-4 line-clamp-2">
                  مركز متخصص في تدريب الشباب على المهارات التقنية الحديثة وربطهم بسوق العمل المحلي والعالمي.
                </p>
                <div className="mb-4">
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-700">التمويل</span>
                    <span className="text-primary font-medium">45%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-primary h-2.5 rounded-full" style={{ width: '45%' }}></div>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-700">$120,000</span>
                  <Link to="/projects/tech-training-center" className="btn btn-sm btn-primary">
                    تفاصيل
                  </Link>
                </div>
              </div>
            </div>
          </div>
          <div className="text-center mt-10">
            <Link to="/projects" className="btn btn-outline btn-lg">
              عرض جميع المشاريع
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">كيف تعمل منصة تمكين؟</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">1</div>
              <h3 className="text-xl font-semibold mb-2">إنشاء حساب</h3>
              <p className="text-gray-600">
                سجل في المنصة وأكمل ملفك الشخصي للوصول إلى جميع الخدمات والفرص الاستثمارية.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">2</div>
              <h3 className="text-xl font-semibold mb-2">استكشف المشاريع</h3>
              <p className="text-gray-600">
                تصفح المشاريع المتاحة واختر ما يناسب اهتماماتك وأهدافك الاستثمارية.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">3</div>
              <h3 className="text-xl font-semibold mb-2">استثمر بأمان</h3>
              <p className="text-gray-600">
                اختر قيمة استثمارك وأكمل عملية الدفع بطريقة آمنة وسهلة عبر وسائل دفع متعددة.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">4</div>
              <h3 className="text-xl font-semibold mb-2">تابع استثماراتك</h3>
              <p className="text-gray-600">
                راقب تقدم مشاريعك واحصل على تحديثات دورية وعوائد استثمارية حسب أداء المشروع.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">آراء المستثمرين</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <img 
                  src="/assets/images/testimonial1.jpg" 
                  alt="محمد أحمد" 
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-semibold">محمد أحمد</h4>
                  <p className="text-gray-500 text-sm">مستثمر من السعودية</p>
                </div>
              </div>
              <p className="text-gray-600">
                "منصة تمكين فتحت لي آفاقاً جديدة للاستثمار في بلدي الأصلي. الشفافية والمتابعة المستمرة للمشاريع جعلتني أشعر بالثقة والاطمئنان."
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <img 
                  src="/assets/images/testimonial2.jpg" 
                  alt="سارة محمود" 
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-semibold">سارة محمود</h4>
                  <p className="text-gray-500 text-sm">مستثمرة من الإمارات</p>
                </div>
              </div>
              <p className="text-gray-600">
                "أحب فكرة المساهمة في تنمية المجتمعات المحلية من خلال الاستثمار. منصة تمكين تقدم فرصاً متنوعة تناسب جميع المستثمرين."
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <img 
                  src="/assets/images/testimonial3.jpg" 
                  alt="خالد العمري" 
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-semibold">خالد العمري</h4>
                  <p className="text-gray-500 text-sm">مستثمر من قطر</p>
                </div>
              </div>
              <p className="text-gray-600">
                "العوائد الاستثمارية ممتازة، والأهم من ذلك هو الأثر الاجتماعي الإيجابي للمشاريع. أنصح كل مغترب بالاستثمار عبر منصة تمكين."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Partners Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">شركاؤنا</h2>
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16">
            <img src="/assets/images/partner1.png" alt="شريك 1" className="h-12 grayscale hover:grayscale-0 transition-all" />
            <img src="/assets/images/partner2.png" alt="شريك 2" className="h-12 grayscale hover:grayscale-0 transition-all" />
            <img src="/assets/images/partner3.png" alt="شريك 3" className="h-
(Content truncated due to size limit. Use line ranges to read in chunks)