import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../layouts/MainLayout';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/ui/use-toast';

const CreateInvestmentGroupPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    image: '',
    min_investment: '',
    target_amount: '',
    project_id: ''
  });
  const [loading, setLoading] = useState(false);
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  // محاكاة قائمة المشاريع المتاحة
  const availableProjects = [
    { id: 1, name: 'مشروع زراعة الكاكاو العضوي' },
    { id: 2, name: 'متجر إلكتروني للمنتجات المحلية' },
    { id: 3, name: 'مركز تدريب تقني' },
    { id: 4, name: 'مشروع الطاقة الشمسية للمناطق الريفية' },
    { id: 5, name: 'عيادة متنقلة للمناطق النائية' },
    { id: 6, name: 'تطبيق تعليمي للأطفال' }
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isAuthenticated) {
      toast({
        title: "يرجى تسجيل الدخول",
        description: "يجب عليك تسجيل الدخول لإنشاء مجموعة استثمارية",
        variant: "destructive",
      });
      navigate('/login');
      return;
    }
    
    // التحقق من البيانات المطلوبة
    if (!formData.name || !formData.description || !formData.min_investment || !formData.target_amount) {
      toast({
        title: "بيانات غير مكتملة",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive",
      });
      return;
    }
    
    // التحقق من صحة المبالغ
    const minInvestment = parseFloat(formData.min_investment);
    const targetAmount = parseFloat(formData.target_amount);
    
    if (isNaN(minInvestment) || minInvestment <= 0) {
      toast({
        title: "مبلغ غير صالح",
        description: "يرجى إدخال الحد الأدنى للاستثمار بشكل صحيح",
        variant: "destructive",
      });
      return;
    }
    
    if (isNaN(targetAmount) || targetAmount <= 0) {
      toast({
        title: "مبلغ غير صالح",
        description: "يرجى إدخال المبلغ المستهدف بشكل صحيح",
        variant: "destructive",
      });
      return;
    }
    
    if (minInvestment > targetAmount) {
      toast({
        title: "خطأ في المبالغ",
        description: "الحد الأدنى للاستثمار يجب أن يكون أقل من المبلغ المستهدف",
        variant: "destructive",
      });
      return;
    }
    
    setLoading(true);
    
    // محاكاة طلب API لإنشاء المجموعة
    setTimeout(() => {
      toast({
        title: "تم إنشاء المجموعة بنجاح",
        description: `تم إنشاء مجموعة "${formData.name}" بنجاح`,
      });
      
      navigate('/investment-groups');
      setLoading(false);
    }, 1500);
  };

  return (
    <MainLayout>
      <div className="bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-md p-8">
            <h1 className="text-3xl font-bold mb-6 text-center text-primary">إنشاء مجموعة استثمارية جديدة</h1>
            
            <form onSubmit={handleSubmit}>
              <div className="mb-6">
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">اسم المجموعة *</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="أدخل اسم المجموعة"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="mb-6">
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">وصف المجموعة *</label>
                <textarea
                  id="description"
                  name="description"
                  rows={5}
                  className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="أدخل وصفاً تفصيلياً للمجموعة وأهدافها"
                  value={formData.description}
                  onChange={handleChange}
                  required
                ></textarea>
              </div>
              
              <div className="mb-6">
                <label htmlFor="image" className="block text-sm font-medium text-gray-700 mb-1">رابط صورة المجموعة</label>
                <input
                  type="text"
                  id="image"
                  name="image"
                  className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="أدخل رابط صورة للمجموعة"
                  value={formData.image}
                  onChange={handleChange}
                />
                <p className="text-sm text-gray-500 mt-1">اختياري: أدخل رابط صورة تمثل المجموعة</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="min_investment" className="block text-sm font-medium text-gray-700 mb-1">الحد الأدنى للاستثمار ($) *</label>
                  <input
                    type="number"
                    id="min_investment"
                    name="min_investment"
                    className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="مثال: 1000"
                    value={formData.min_investment}
                    onChange={handleChange}
                    min="1"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="target_amount" className="block text-sm font-medium text-gray-700 mb-1">المبلغ المستهدف ($) *</label>
                  <input
                    type="number"
                    id="target_amount"
                    name="target_amount"
                    className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="مثال: 100000"
                    value={formData.target_amount}
                    onChange={handleChange}
                    min="1"
                    required
                  />
                </div>
              </div>
              
              <div className="mb-8">
                <label htmlFor="project_id" className="block text-sm font-medium text-gray-700 mb-1">المشروع الرئيسي</label>
                <select
                  id="project_id"
                  name="project_id"
                  className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  value={formData.project_id}
                  onChange={handleChange}
                >
                  <option value="">-- اختر المشروع الرئيسي (اختياري) --</option>
                  {availableProjects.map(project => (
                    <option key={project.id} value={project.id}>{project.name}</option>
                  ))}
                </select>
                <p className="text-sm text-gray-500 mt-1">اختياري: يمكنك تحديد مشروع رئيسي تركز عليه المجموعة</p>
              </div>
              
              <div className="flex justify-between items-center">
                <button
                  type="button"
                  className="btn btn-outline"
                  onClick={() => navigate('/investment-groups')}
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="loading loading-spinner loading-sm"></span>
                      جاري الإنشاء...
                    </>
                  ) : 'إنشاء المجموعة'}
                </button>
              </div>
            </form>
            
            <div className="mt-8 p-4 bg-blue-50 rounded-lg">
              <h3 className="text-lg font-semibold mb-2 text-blue-700">معلومات مهمة</h3>
              <ul className="list-disc list-inside text-blue-700 space-y-1">
                <li>عند إنشاء المجموعة، ستصبح أنت قائد المجموعة تلقائياً</li>
                <li>يمكنك تعديل بيانات المجموعة لاحقاً من صفحة إدارة المجموعة</li>
                <li>يجب عليك المساهمة بمبلغ استثماري لا يقل عن الحد الأدنى للاستثمار</li>
                <li>يمكنك إنشاء تصويتات واستثمارات للمجموعة بعد إنشائها</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default CreateInvestmentGroupPage;
