# هيكل قاعدة البيانات لنظام بنك الاتحاد

## مقدمة

يقدم هذا المستند تصميماً تفصيلياً لهيكل قاعدة البيانات لنظام بنك الاتحاد، بما في ذلك الجداول، العلاقات، والحقول الرئيسية. تم تصميم هذا الهيكل ليدعم جميع المتطلبات الوظيفية المحددة سابقاً، مع مراعاة المرونة وقابلية التوسع.

## مخطط قاعدة البيانات

### 1. مجموعة جداول المستخدمين والحسابات

#### 1.1 جدول المستخدمين (users)

```sql
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone_number VARCHAR(20),
    is_active BOOLEAN DEFAULT TRUE,
    is_verified BOOLEAN DEFAULT FALSE,
    verification_token VARCHAR(100),
    reset_token VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP
);
```

#### 1.2 جدول الأدوار (roles)

```sql
CREATE TABLE roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 1.3 جدول أدوار المستخدمين (user_roles)

```sql
CREATE TABLE user_roles (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    role_id INTEGER REFERENCES roles(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, role_id)
);
```

#### 1.4 جدول الملفات الشخصية (user_profiles)

```sql
CREATE TABLE user_profiles (
    id SERIAL PRIMARY KEY,
    user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    date_of_birth DATE,
    gender VARCHAR(10),
    nationality VARCHAR(50),
    address TEXT,
    city VARCHAR(50),
    country VARCHAR(50),
    postal_code VARCHAR(20),
    bio TEXT,
    profile_picture VARCHAR(255),
    id_document_type VARCHAR(50),
    id_document_number VARCHAR(50),
    id_document_image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 1.5 جدول العضويات (memberships)

```sql
CREATE TABLE memberships (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    membership_type VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    payment_id INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 2. مجموعة جداول المشاريع

#### 2.1 جدول المشاريع (projects)

```sql
CREATE TABLE projects (
    id SERIAL PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    short_description VARCHAR(255),
    category_id INTEGER REFERENCES project_categories(id),
    location VARCHAR(100),
    country VARCHAR(50),
    target_amount DECIMAL(15, 2) NOT NULL,
    current_amount DECIMAL(15, 2) DEFAULT 0,
    start_date DATE NOT NULL,
    end_date DATE,
    status VARCHAR(20) NOT NULL, -- (active, completed, cancelled, pending)
    risk_level VARCHAR(20),
    expected_return DECIMAL(5, 2),
    min_investment DECIMAL(10, 2),
    featured BOOLEAN DEFAULT FALSE,
    cover_image VARCHAR(255),
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 2.2 جدول تصنيفات المشاريع (project_categories)

```sql
CREATE TABLE project_categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    icon VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 2.3 جدول تحديثات المشاريع (project_updates)

```sql
CREATE TABLE project_updates (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    title VARCHAR(100) NOT NULL,
    content TEXT NOT NULL,
    update_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 2.4 جدول وثائق المشاريع (project_documents)

```sql
CREATE TABLE project_documents (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    file_path VARCHAR(255) NOT NULL,
    document_type VARCHAR(50),
    is_public BOOLEAN DEFAULT TRUE,
    uploaded_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 2.5 جدول مؤشرات الأثر (impact_metrics)

```sql
CREATE TABLE impact_metrics (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    metric_name VARCHAR(100) NOT NULL,
    metric_value VARCHAR(100) NOT NULL,
    metric_unit VARCHAR(50),
    measurement_date DATE,
    description TEXT,
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 3. مجموعة جداول المالية

#### 3.1 جدول المعاملات (transactions)

```sql
CREATE TABLE transactions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    project_id INTEGER REFERENCES projects(id),
    transaction_type VARCHAR(50) NOT NULL, -- (investment, withdrawal, transfer, fee)
    amount DECIMAL(15, 2) NOT NULL,
    currency VARCHAR(10) DEFAULT 'EUR',
    status VARCHAR(20) NOT NULL, -- (pending, completed, failed, cancelled)
    payment_method VARCHAR(50),
    transaction_reference VARCHAR(100) UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3.2 جدول الاستثمارات (investments)

```sql
CREATE TABLE investments (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    project_id INTEGER REFERENCES projects(id),
    transaction_id INTEGER REFERENCES transactions(id),
    amount DECIMAL(15, 2) NOT NULL,
    investment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expected_return_rate DECIMAL(5, 2),
    status VARCHAR(20) NOT NULL, -- (active, completed, cancelled)
    return_amount DECIMAL(15, 2),
    return_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3.3 جدول طرق الدفع (payment_methods)

```sql
CREATE TABLE payment_methods (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    method_type VARCHAR(50) NOT NULL, -- (credit_card, bank_account, paypal, etc.)
    provider VARCHAR(50),
    account_number VARCHAR(255),
    expiry_date VARCHAR(10),
    is_default BOOLEAN DEFAULT FALSE,
    is_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3.4 جدول السندات (bonds)

```sql
CREATE TABLE bonds (
    id SERIAL PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    total_value DECIMAL(15, 2) NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_units INTEGER NOT NULL,
    available_units INTEGER NOT NULL,
    interest_rate DECIMAL(5, 2) NOT NULL,
    maturity_period INTEGER NOT NULL, -- in months
    issue_date DATE NOT NULL,
    maturity_date DATE NOT NULL,
    status VARCHAR(20) NOT NULL, -- (active, closed, cancelled)
    backed_by VARCHAR(100), -- asset backing the bond
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3.5 جدول مشتريات السندات (bond_purchases)

```sql
CREATE TABLE bond_purchases (
    id SERIAL PRIMARY KEY,
    bond_id INTEGER REFERENCES bonds(id),
    user_id INTEGER REFERENCES users(id),
    transaction_id INTEGER REFERENCES transactions(id),
    units_purchased INTEGER NOT NULL,
    purchase_amount DECIMAL(15, 2) NOT NULL,
    purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) NOT NULL, -- (active, matured, sold)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 4. مجموعة جداول المحتوى الإعلامي

#### 4.1 جدول المقالات (articles)

```sql
CREATE TABLE articles (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    content TEXT NOT NULL,
    excerpt TEXT,
    featured_image VARCHAR(255),
    author_id INTEGER REFERENCES users(id),
    status VARCHAR(20) NOT NULL, -- (draft, published, archived)
    published_at TIMESTAMP,
    category_id INTEGER REFERENCES content_categories(id),
    view_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 4.2 جدول تصنيفات المحتوى (content_categories)

```sql
CREATE TABLE content_categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    slug VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    parent_id INTEGER REFERENCES content_categories(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 4.3 جدول الوسوم (tags)

```sql
CREATE TABLE tags (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    slug VARCHAR(50) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 4.4 جدول علاقة المقالات بالوسوم (article_tags)

```sql
CREATE TABLE article_tags (
    id SERIAL PRIMARY KEY,
    article_id INTEGER REFERENCES articles(id) ON DELETE CASCADE,
    tag_id INTEGER REFERENCES tags(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (article_id, tag_id)
);
```

#### 4.5 جدول التعليقات (comments)

```sql
CREATE TABLE comments (
    id SERIAL PRIMARY KEY,
    article_id INTEGER REFERENCES articles(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id),
    parent_id INTEGER REFERENCES comments(id),
    content TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'pending', -- (pending, approved, rejected)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 5. مجموعة جداول النظام

#### 5.1 جدول الإشعارات (notifications)

```sql
CREATE TABLE notifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50), -- (system, transaction, project, etc.)
    is_read BOOLEAN DEFAULT FALSE,
    related_entity_type VARCHAR(50), -- (project, transaction, article, etc.)
    related_entity_id INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 5.2 جدول سجلات النظام (system_logs)

```sql
CREATE TABLE system_logs (
    id SERIAL PRIMARY KEY,
    log_level VARCHAR(20) NOT NULL, -- (info, warning, error, critical)
    message TEXT NOT NULL,
    source VARCHAR(100),
    ip_address VARCHAR(45),
    user_id INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 5.3 جدول سجلات المراجعة (audit_trails)

```sql
CREATE TABLE audit_trails (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    action VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id INTEGER,
    old_values JSONB,
    new_values JSONB,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 5.4 جدول إعدادات النظام (settings)

```sql
CREATE TABLE settings (
    id SERIAL PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_group VARCHAR(50),
    is_public BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## العلاقات الرئيسية

1. **المستخدمون والأدوار**: علاقة متعددة لمتعدد (many-to-many) من خلال جدول user_roles
2. **المستخدمون والمشاريع**: علاقة واحد لمتعدد (one-to-many) حيث يمكن للمستخدم إنشاء عدة مشاريع
3. **المشاريع والاستثمارات**: علاقة واحد لمتعدد (one-to-many) حيث يمكن للمشروع أن يحتوي على عدة استثمارات
4. **المستخدمون والاستثمارات**: علاقة واحد لمتعدد (one-to-many) حيث يمكن للمستخدم أن يقوم بعدة استثمارات
5. **المقالات والتصنيفات**: علاقة متعدد لواحد (many-to-one) حيث ينتمي كل مقال إلى تصنيف واحد
6. **المقالات والوسوم**: علاقة متعددة لمتعدد (many-to-many) من خلال جدول article_tags

## مخطط البيانات الأولي

سيتم إنشاء البيانات الأولية التالية عند تهيئة قاعدة البيانات:

### 1. الأدوار الأساسية

```sql
INSERT INTO roles (name, description) VALUES
('admin', 'مدير النظام مع صلاحيات كاملة'),
('manager', 'مدير مع صلاحيات إدارية محدودة'),
('editor', 'محرر للمحتوى الإعلامي'),
('project_manager', 'مدير المشاريع'),
('financial_manager', 'مدير مالي'),
('investor', 'مستثمر'),
('user', 'مستخدم عادي');
```

### 2. تصنيفات المشاريع

```sql
INSERT INTO project_categories (name, description) VALUES
('زراعي', 'مشاريع زراعية وإنتاج غذائي'),
('صناعي', 'مشاريع صناعية وتصنيعية'),
('تعليمي', 'مشاريع تعليمية وتدريبية'),
('صحي', 'مشاريع صحية وطبية'),
('تقني', 'مشاريع تقنية وتكنولوجية'),
('تجاري', 'مشاريع تجارية وخدمية');
```

### 3. تصنيفات المحتوى

```sql
INSERT INTO content_categories (name, slug, description) VALUES
('أخبار', 'news', 'أخبار وتحديثات عن المشاريع والمبادرات'),
('تقارير', 'reports', 'تقارير مالية وتنموية'),
('قصص نجاح', 'success-stories', 'قصص نجاح المشاريع والمستفيدين'),
('مقالات تعليمية', 'educational', 'مقالات تعليمية حول الاستثمار والتنمية'),
('إعلانات', 'announcements', 'إعلانات وتنبيهات هامة');
```

## ملاحظات تنفيذية

1. **الفهارس (Indexes)**: يجب إنشاء فهارس على الحقول التي يتم البحث عنها بشكل متكرر مثل user_id، project_id، وحقول التاريخ.

2. **القيود (Constraints)**: تم تعريف القيود الأساسية مثل المفاتيح الأجنبية والقيم الفريدة، ويمكن إضافة المزيد حسب الحاجة.

3. **التحديثات التلقائية**: تم تعريف حقول created_at وupdated_at لمعظم الجداول، ويمكن إنشاء triggers لتحديث حقل updated_at تلقائياً.

4. **الأمان**: يجب تشفير البيانات الحساسة مثل كلمات المرور وبيانات الدفع.

5. **الترحيل (Migration)**: يجب إنشاء ملفات ترحيل لتسهيل تحديث هيكل قاعدة البيانات في المستقبل.

## الخلاصة

يقدم هذا التصميم هيكلاً شاملاً لقاعدة بيانات نظام بنك الاتحاد، مع مراعاة جميع المتطلبات الوظيفية المحددة سابقاً. يمكن توسيع هذا الهيكل أو تعديله حسب الحاجة أثناء تطوير النظام.
