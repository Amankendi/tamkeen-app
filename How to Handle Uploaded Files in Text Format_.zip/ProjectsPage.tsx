import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import MainLayout from '../layouts/MainLayout';
import { useAuth } from '../contexts/AuthContext';

const ProjectsPage: React.FC = () => {
  const [projects, setProjects] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    const fetchData = async () => {
      try {
        // محاكاة طلب API للفئات
        setTimeout(() => {
          const mockCategories = [
            { id: 1, name: 'زراعي', slug: 'agriculture', project_count: 12 },
            { id: 2, name: 'صناعي', slug: 'industrial', project_count: 8 },
            { id: 3, name: 'تعليمي', slug: 'education', project_count: 5 },
            { id: 4, name: 'صحي', slug: 'health', project_count: 7 },
            { id: 5, name: 'تقني', slug: 'technology', project_count: 10 },
            { id: 6, name: 'تجاري', slug: 'commercial', project_count: 15 }
          ];
          setCategories(mockCategories);
          
          // محاكاة طلب API للمشاريع
          const mockProjects = [
            {
              id: 1,
              title: 'مشروع زراعة الكاكاو العضوي',
              slug: 'cacao-farming',
              short_description: 'مشروع لزراعة الكاكاو العضوي في الإكوادور، يهدف إلى دعم المزارعين المحليين وتحسين جودة الإنتاج.',
              category: 'زراعي',
              category_id: 1,
              location: 'الإكوادور',
              target_amount: 100000,
              current_amount: 80000,
              funding_percentage: 80,
              status: 'active',
              featured: true,
              cover_image: '/assets/images/project1.jpg',
              created_at: '2024-12-15 10:30:00'
            },
            {
              id: 2,
              title: 'متجر إلكتروني للمنتجات المحلية',
              slug: 'local-ecommerce',
              short_description: 'منصة تجارة إلكترونية متخصصة في تسويق المنتجات اليدوية والتراثية اليمنية للأسواق العالمية.',
              category: 'تجاري',
              category_id: 6,
              location: 'اليمن',
              target_amount: 75000,
              current_amount: 48750,
              funding_percentage: 65,
              status: 'active',
              featured: true,
              cover_image: '/assets/images/project2.jpg',
              created_at: '2025-01-05 14:20:00'
            },
            {
              id: 3,
              title: 'مركز تدريب تقني',
              slug: 'tech-training-center',
              short_description: 'مركز متخصص في تدريب الشباب على المهارات التقنية الحديثة وربطهم بسوق العمل المحلي والعالمي.',
              category: 'تعليمي',
              category_id: 3,
              location: 'الأردن',
              target_amount: 120000,
              current_amount: 54000,
              funding_percentage: 45,
              status: 'active',
              featured: true,
              cover_image: '/assets/images/project3.jpg',
              created_at: '2025-01-10 09:15:00'
            },
            {
              id: 4,
              title: 'مشروع الطاقة الشمسية للمناطق الريفية',
              slug: 'rural-solar-energy',
              short_description: 'مشروع لتوفير الطاقة الشمسية للمناطق الريفية النائية، وتحسين جودة الحياة للسكان المحليين.',
              category: 'صناعي',
              category_id: 2,
              location: 'المغرب',
              target_amount: 150000,
              current_amount: 90000,
              funding_percentage: 60,
              status: 'active',
              featured: false,
              cover_image: '/assets/images/project4.jpg',
              created_at: '2025-01-15 11:45:00'
            },
            {
              id: 5,
              title: 'عيادة متنقلة للمناطق النائية',
              slug: 'mobile-clinic',
              short_description: 'عيادة متنقلة لتقديم الخدمات الصحية الأساسية للمناطق النائية التي تفتقر إلى الرعاية الصحية.',
              category: 'صحي',
              category_id: 4,
              location: 'موريتانيا',
              target_amount: 85000,
              current_amount: 25500,
              funding_percentage: 30,
              status: 'active',
              featured: false,
              cover_image: '/assets/images/project5.jpg',
              created_at: '2025-01-20 13:10:00'
            },
            {
              id: 6,
              title: 'تطبيق تعليمي للأطفال',
              slug: 'educational-app',
              short_description: 'تطبيق تعليمي تفاعلي للأطفال، يهدف إلى تعليم اللغة العربية والمهارات الأساسية بطريقة ممتعة.',
              category: 'تقني',
              category_id: 5,
              location: 'مصر',
              target_amount: 60000,
              current_amount: 42000,
              funding_percentage: 70,
              status: 'active',
              featured: false,
              cover_image: '/assets/images/project6.jpg',
              created_at: '2025-01-25 10:00:00'
            }
          ];
          setProjects(mockProjects);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // تصفية المشاريع حسب الفئة والبحث
  const filteredProjects = projects.filter(project => {
    const matchesCategory = activeCategory ? project.category_id === activeCategory : true;
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          project.short_description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <MainLayout>
      <div className="bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-8 text-center">استكشف المشاريع</h1>
          
          {/* شريط البحث */}
          <div className="mb-8">
            <div className="max-w-md mx-auto">
              <div className="relative">
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                  </svg>
                </div>
                <input
                  type="search"
                  className="block w-full p-4 pr-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-white focus:ring-primary focus:border-primary"
                  placeholder="ابحث عن مشاريع..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </div>
          
          {/* فئات المشاريع */}
          <div className="mb-8">
            <div className="flex flex-wrap justify-center gap-2">
              <button
                className={`px-4 py-2 rounded-full text-sm font-medium ${activeCategory === null ? 'bg-primary text-white' : 'bg-white text-gray-700 hover:bg-gray-100'}`}
                onClick={() => setActiveCategory(null)}
              >
                الكل
              </button>
              {categories.map(category => (
                <button
                  key={category.id}
                  className={`px-4 py-2 rounded-full text-sm font-medium ${activeCategory === category.id ? 'bg-primary text-white' : 'bg-white text-gray-700 hover:bg-gray-100'}`}
                  onClick={() => setActiveCategory(category.id)}
                >
                  {category.name} ({category.project_count})
                </button>
              ))}
            </div>
          </div>
          
          {/* قائمة المشاريع */}
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : filteredProjects.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProjects.map(project => (
                <div key={project.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                  <img 
                    src={project.cover_image} 
                    alt={project.title} 
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <div className="flex justify-between items-center mb-2">
                      <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">{project.category}</span>
                      <span className="text-gray-500 text-sm">{project.location}</span>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                    <p className="text-gray-600 mb-4 line-clamp-2">
                      {project.short_description}
                    </p>
                    <div className="mb-4">
                      <div className="flex justify-between mb-1">
                        <span className="text-gray-700">التمويل</span>
                        <span className="text-primary font-medium">{project.funding_percentage}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-primary h-2.5 rounded-full" style={{ width: `${project.funding_percentage}%` }}></div>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">${project.target_amount.toLocaleString()}</span>
                      <Link to={`/projects/${project.slug}`} className="btn btn-sm btn-primary">
                        تفاصيل
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold mb-4">لا توجد مشاريع</h2>
              <p className="mb-6">لم يتم العثور على مشاريع تطابق معايير البحث.</p>
              <button 
                onClick={() => {
                  setActiveCategory(null);
                  setSearchTerm('');
                }}
                className="btn btn-primary"
              >
                عرض جميع المشاريع
              </button>
            </div>
          )}
          
          {/* دعوة للاستثمار */}
          <div className="mt-16 bg-primary text-white rounded-lg p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">هل أنت مستعد للاستثمار؟</h2>
            <p className="mb-6 max-w-2xl mx-auto">
              انضم إلى آلاف المستثمرين الذين يساهمون في تنمية بلدانهم ويحققون عوائد مالية مجزية.
            </p>
            {isAuthenticated ? (
              <Link to="/dashboard" className="btn bg-white text-primary hover:bg-gray-100">
                لوحة التحكم
              </Link>
            ) : (
              <div className="flex flex-wrap justify-center gap-4">
                <Link to="/register" className="btn bg-white text-primary hover:bg-gray-100">
                  إنشاء حساب
                </Link>
                <Link to="/login" className="btn btn-outline border-white text-white hover:bg-white hover:text-primary">
                  تسجيل الدخول
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default ProjectsPage;
