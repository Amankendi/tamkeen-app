from flask import Flask, jsonify, request
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
import datetime
import os
from functools import wraps

# Import models
from src.models.user import db as user_db, User, Role, UserProfile
from src.models.project import db as project_db, Project, ProjectCategory
from src.models.financial import db as financial_db, Transaction, Investment
from src.models.content import db as content_db, Article, ContentCategory
from src.models.system import db as system_db, Notification, Setting

app = Flask(__name__)
CORS(app)

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'tamken_secret_key')
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'tamken_db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize databases
user_db.init_app(app)
project_db.init_app(app)
financial_db.init_app(app)
content_db.init_app(app)
system_db.init_app(app)

# Token required decorator
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith('Bearer '):
                token = auth_header.split(' ')[1]
        
        if not token:
            return jsonify({'message': 'Token is missing!'}), 401
        
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = User.query.filter_by(id=data['user_id']).first()
        except:
            return jsonify({'message': 'Token is invalid!'}), 401
        
        return f(current_user, *args, **kwargs)
    
    return decorated

# Import routes
from src.routes.auth import auth_bp
from src.routes.users import users_bp
from src.routes.projects import projects_bp
from src.routes.investments import investments_bp
from src.routes.content import content_bp
from src.routes.admin import admin_bp

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(users_bp, url_prefix='/api/users')
app.register_blueprint(projects_bp, url_prefix='/api/projects')
app.register_blueprint(investments_bp, url_prefix='/api/investments')
app.register_blueprint(content_bp, url_prefix='/api/content')
app.register_blueprint(admin_bp, url_prefix='/api/admin')

@app.route('/')
def index():
    return jsonify({
        'message': 'Welcome to Tamken Platform API',
        'version': '1.0.0',
        'status': 'active'
    })

@app.route('/api/health')
def health_check():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.datetime.now().isoformat()
    })

# Create database tables
@app.before_first_request
def create_tables():
    user_db.create_all()
    project_db.create_all()
    financial_db.create_all()
    content_db.create_all()
    system_db.create_all()
    
    # Create initial roles if they don't exist
    if Role.query.count() == 0:
        roles = [
            Role('admin', 'مدير النظام مع صلاحيات كاملة'),
            Role('manager', 'مدير مع صلاحيات إدارية محدودة'),
            Role('editor', 'محرر للمحتوى الإعلامي'),
            Role('project_manager', 'مدير المشاريع'),
            Role('financial_manager', 'مدير مالي'),
            Role('investor', 'مستثمر'),
            Role('user', 'مستخدم عادي')
        ]
        for role in roles:
            user_db.session.add(role)
        
        user_db.session.commit()
    
    # Create initial project categories if they don't exist
    if ProjectCategory.query.count() == 0:
        categories = [
            ProjectCategory('زراعي', 'مشاريع زراعية وإنتاج غذائي'),
            ProjectCategory('صناعي', 'مشاريع صناعية وتصنيعية'),
            ProjectCategory('تعليمي', 'مشاريع تعليمية وتدريبية'),
            ProjectCategory('صحي', 'مشاريع صحية وطبية'),
            ProjectCategory('تقني', 'مشاريع تقنية وتكنولوجية'),
            ProjectCategory('تجاري', 'مشاريع تجارية وخدمية')
        ]
        for category in categories:
            project_db.session.add(category)
        
        project_db.session.commit()
    
    # Create initial content categories if they don't exist
    if ContentCategory.query.count() == 0:
        categories = [
            ContentCategory(name='أخبار', slug='news', description='أخبار وتحديثات عن المشاريع والمبادرات'),
            ContentCategory(name='تقارير', slug='reports', description='تقارير مالية وتنموية'),
            ContentCategory(name='قصص نجاح', slug='success-stories', description='قصص نجاح المشاريع والمستفيدين'),
            ContentCategory(name='مقالات تعليمية', slug='educational', description='مقالات تعليمية حول الاستثمار والتنمية'),
            ContentCategory(name='إعلانات', slug='announcements', description='إعلانات وتنبيهات هامة')
        ]
        for category in categories:
            content_db.session.add(category)
        
        content_db.session.commit()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
